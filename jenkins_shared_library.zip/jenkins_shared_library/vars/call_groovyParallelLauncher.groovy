def call(Map groovyfunctions) {
    new com.scor.utils.groovyParallelLauncher().call(groovyfunctions)
}
