def call(Map config) {
node ('dcvprdadm04') {
currentBuild.displayName = "${config.project_name}-${config.environment}-${BUILD_NUMBER}"
new com.scor.utils.setGlobalConfiguration().call(config)
new com.scor.infrastructure.ansible.azure.DXC.windowsVm_v2().call(config)
new com.scor.infrastructure.ansible.azure.windowsVmJoinDomain().call(config)
}
}