def call() {
global_var_map = [
    project_name : "APEX",
    sonar_gateid : "low-restriction-not-blocking",
    maven_sonar_profile : "coverage",
    maven_rootpom_directory : "",
    mavenPomNameAnchor : "name",
    node_name : "dcvprdadm04",
    build_environment : "DEV",
    assemblyArtifactId : "APEX_NOTEBOOKS",
    assemblyExtension : "tar",
    assemblyClassifier : "assembly",
    databricksImportDir : "/Shared",
    databricksScope : "apexKeys"
]

node ("${global_var_map.node_name}") {
    List javaEnv = new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    withEnv(javaEnv) {
    new com.scor.utils.scmCheckout().call()
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    new com.scor.maven.updateConfiguration().call(global_var_map)
    new com.scor.utils.buildDisplayName().call(global_var_map)
    new com.scor.maven.releaseversionControl().call(global_var_map)
    new com.scor.maven.scanJar().call(global_var_map)
    new com.scor.maven.codeAnalyser_sonarScanner().call(global_var_map)
    new com.scor.maven.jarParallelLauncher().call(global_var_map, "call_retrieveJarFromNexusNoClassifier", "Retrieve Jar From Nexus" )
    new com.scor.maven.jarParallelLauncher().call(global_var_map, "call_databricksCopyJar", "Copy Jar in databricks DBFS" )
    new com.scor.nexus.retrieveFromNexusClassifier().call(global_var_map)
    new com.scor.databricks.importDir().call(global_var_map)
    new com.scor.sweagle.getConfigurationStandalone().call(global_var_map, "apex-data")
    new com.scor.databricks.pushSecret().call(global_var_map, "apex-data")
    if ( "${global_var_map.environment}" == "DEV") {
    global_var_map << [clusterid : "1202-150315-nape794"]
    }
    new com.scor.databricks.restartCluster().call(global_var_map)
    new com.scor.utils.influxdb().record(global_var_map)
    new com.scor.utils.mail().send(global_var_map)
    }
}
}