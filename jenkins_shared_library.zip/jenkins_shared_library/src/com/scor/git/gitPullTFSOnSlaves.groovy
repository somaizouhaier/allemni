package com.scor.git

def call(Map config) {
    //required parameter in map in output oj the jenksin job : UserProjectName, UserGitRepoName, collection
node ('master') {

// variables :
def GIT_url="ssh://tfs-corporate.eu.scor.local:22"
def Git_user="EU\\\\SVC_CI_PRD"
def Git_token="35fsplxlclk66zgoltb2obfhcpoxsgqxe6dyox5ujmhf354nt5pa"
def Git_credential="174ccc7c-b842-4cd1-a66b-8fac545156b9"
def Api_version="4.1"
def Node_label="unix"

//branch to pull from the branch name
// def branch=env.BRANCH_NAME [ activate it with a mutlibranch pipelines ]
def branch="${config.UserBranch}"
if (branch == "master") {
root_path = "/scor/${config.collection}"
} else {
root_path = "/scor/${config.collection}-${branch}"
}


// variables

//map definition
def full_map_projects = [:]
def full_map_repositories = [:]
//map definition

//Jenkins stages
stage ("TFS collection : ${config.collection}, pull project : ${config.UserProjectName}, repository : ${config.UserGitRepoName}") {
        currentBuild.displayName = "${config.collection} - project : ${config.UserProjectName} - repository : ${config.UserGitRepoName} - branch : ${config.UserBranch}"
        def nodes_list = []
        jenkins.model.Jenkins.instance.computers.each { c ->
        if (c.node.labelString.contains("${Node_label}")) {
            nodes_list.add(c.node.selfLabel.name)          
        }
    }
    for (node_name in nodes_list) {
        node_launcher("${node_name}", "${config.collection}", "${root_path}", "${branch}", "${Git_credential}", "${GIT_url}", "${config.UserProjectName}", "${config.UserGitRepoName}")
    }    
}
//Jenkins stages
//close node master
    }
// close
}

def node_launcher(String node_name, String collection, String root_path, String branch, String git_credential, String git_url, String project, String repository){
    node(node_name) {
        path = sh(returnStdout: true, script: "echo \\${project} | sed -e 's#-#/#g'")
        path = path.trim()
        dir("${root_path}/${path}/${repository}"){
            SCM_checkout ("${collection}", "${project}", "${repository}", "${branch}", "${git_credential}", "${git_url}")
            sh(returnStdout: true, script:"chmod -R 700 *")
        }
        if ("${repository}" == "sshkey_list"){
            dir("${root_path}/${path}/${repository}"){
                sh(returnStdout: true, script:"chmod 600 *")
            }
        }
        if ( "${project.contains("shell")}" == "true") {
            dir("${root_path}/${path}/${repository}"){
                sh(returnStdout: true, script:"dos2unix *")
            }
        }                  
	}
}


def SCM_checkout(String collection, String project, String repository, String branch, String git_credential, String git_url){
checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: "${branch}"]], doGenerateSubmoduleConfigurations: false, extensions: [], submoduleCfg: [], userRemoteConfigs: [[credentialsId: "${git_credential}", url: "${git_url}/${collection}/${project}/_git/${repository}"]]]
}