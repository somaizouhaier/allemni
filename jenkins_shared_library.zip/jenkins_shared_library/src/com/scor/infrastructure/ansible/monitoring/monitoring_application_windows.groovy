package com.scor.infrastructure.ansible.monitoring

def call (Map config) {
stage ("Ansible Create Monitoring : ${config.project_name} ${config.environment}") {
    def exists = fileExists "${config.ansible_config_dir}/monitoring/agent/application/${config.project_name}/${config.environment}/agent_vars.yml"
    def monitoring_instance_env
	if ("${config.environment}" == "non-PRD") {
 	monitoring_instance_env = "nonPRD"
	}
	else if ("${config.environment}" == "PRD") {
	monitoring_instance_env = "prd"
    }
    if (exists) {
    try {
        dir ("${config.ansible_playbook_dir}/monitoring/ansible-playbooks-monitoring") {
        status = sh (
        script: "ansible-playbook playbook_monitoring_application.yml -e app_name=${config.project_name} -e env=${config.environment} -e monitoring_instance_env=${monitoring_instance_env} -e filebeat_agent=${config.filebeat_agent} -i ${config.ansible_config_dir}/monitoring/agent/application/${config.project_name}/${config.environment}/agent_windows_host.yml",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Linux VM: ${config.project_name} ${config.environment}"]
        }
        else if ("${status}" == "0") {
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Linux VM: ${config.project_name} ${config.environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible Create Azure Linux VM: ${config.project_name} ${config.environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
    }
    else {
      println "No Linux VM configured - ${config.project_name} ${config.environment}"
    }
}
}
