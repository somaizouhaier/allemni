package com.scor.sweagle

def call (Map config, String finalName) {
    stage ("Sweagle Get ${finalName} Configuration") {
    try {
        sh "${config.sweagle_shell_dir}/retrieve_all_configuration/scorGetConfigByAppEnvrt.sh ${config.project_name} ${config.environment} ${finalName} ${config.sweagle_stored_dir}"
     } catch (error) {
        new com.scor.utils.catchFailureBuild().call(config, "sweagle get configuration")
       }
    }
}