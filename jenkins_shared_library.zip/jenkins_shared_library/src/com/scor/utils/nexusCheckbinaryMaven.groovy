package com.scor.utils

def call (Map config) {
stage ('Nexus Check Binary Maven') {
	def status
	try {
     	status = sh (
		  script: "/scor/ScorPRDToolkit/nexus/Extract_pom.sh ${config.groupid} ${config.artifactid} ${config.version} /tmp ${config.nexus_host} ${config.nexus_port} pom",
      //wget --user $nexus_user --password $nexus_password --no-check-certificate "${repo}/repository/deploy-releases/${groupIdUrl}/${artifactId}/${version}/${artifactId}-${version}.${type}" -O ${download_repo}/${filename} || exit 1,
     	returnStatus: true
      )
	} catch (error) {
			new com.scor.utils.catchFailureBuild().call(config, "nexus check binary maven")
    }
return status
}
}
