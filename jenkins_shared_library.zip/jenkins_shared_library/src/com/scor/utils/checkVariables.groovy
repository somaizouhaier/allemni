package com.scor.utils

def call (String variable) {
	if ("${variable}" == 'null') {
    	error"\t++ the variable ${variable} is not defined"
	}
}
}