def call() {
global_var_map = [
    project_name : "SOLEM",
    ansible_playbook_dir : "/scor/CI-Factory/ansible/playbooks",
    node_name : "dcvprdadm04",
    build_environment : "DEV"
]

node ("${global_var_map.node_name}") {

    new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    new com.scor.utils.scmCheckout().call()
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    print "${global_var_map.project_name},${global_var_map.environment}"
    new com.scor.sweagle.getProjectInfrastructureConfiguration().call(global_var_map)
    new com.scor.infrastructure.ansible.azure.virtualNetwork().call(global_var_map, "ne")
    new com.scor.infrastructure.ansible.azure.nsg().call(global_var_map)
    //infrastructureAnsibleAzureLinuxVm(global_var_map)
    //infrastructureAnsibleAzureWindowsVm(global_var_map)
    groovyfunctions = [
         call_infrastructureAnsibleAzureLinuxVm : "${global_var_map.project_name},${global_var_map.environment}",
         call_infrastructureAnsibleAzureWindowsVm : "${global_var_map.project_name},${global_var_map.environment}"
    ]
    new com.scor.utils.groovyParallelLauncher().call(groovyfunctions)
    new com.scor.infrastructure.ansible.azure.recoveryServiceVault().call(global_var_map, "ne")
    new com.scor.infrastructure.ansible.azure.monitoring().call(global_var_map)
    new com.scor.infrastructure.ansible.azure.linuxVmJoinDomain().call(global_var_map)
    new com.scor.infrastructure.ansible.azure.windowsVmJoinDomain().call(global_var_map)
    new com.scor.infrastructure.ansible.azure.publicIp().call(global_var_map, "ne")
    //ansible.azure.vmNsg(global_var_map, "false")
    new com.scor.sweagle.uploadHosts().call(global_var_map)
    new com.scor.utils.influxdb().record(global_var_map)
    new com.scor.utils.mail().send(global_var_map)
}
}
