package com.scor.utils

def call (String jdkVersion, String mavenVersion) {
	//add global tool and path
	def jdktool = tool name: jdkVersion, type: 'hudson.model.JDK'
	def mvnHome = tool name: mavenVersion
	def scannerHome = tool name: 'sonar-scanner'
	List javaEnv = [
			"PATH+MVN=${jdktool}/bin:${mvnHome}/bin",
			"M2_HOME=${mvnHome}",
			"JAVA_HOME=${jdktool}"
	]

	return javaEnv
}