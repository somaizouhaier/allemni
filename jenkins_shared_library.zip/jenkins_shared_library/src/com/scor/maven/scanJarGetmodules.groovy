package com.scor.maven

def call (Map fullmapmodule, String rootPompath) {
    rootPomfile = readMavenPom file: "${rootPompath}/pom.xml"
    if ("${rootPomfile.modules.size()}" > 0) {
        for (modules in rootPomfile.modules) {
            new com.scor.maven.scanJarGetmodules().call(fullmapmodule, "${rootPompath}/${modules}")
    }} else {
            fullmapmodule.put("${rootPomfile.artifactId}", "${rootPompath}/pom.xml")
	}
}
return fullmapmodule