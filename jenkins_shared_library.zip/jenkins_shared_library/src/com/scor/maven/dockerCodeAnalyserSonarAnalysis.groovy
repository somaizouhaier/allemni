package com.scor.maven

def call(Map config) {
       stage('Maven Sonar Analysis') {
	try {
    def flag_empty_rootpom_directory = 0
    def Sonarprops
    def reportTask
    if ("${config.maven_rootpom_directory}" == "") {
        flag_empty_rootpom_directory = flag_empty_rootpom_directory + 1
    }
	withSonarQubeEnv('SonarQube-PRD') {
		sh "export SONAR_USER_HOME=/scor/delivery/sonar_cache && cd ${config.workspace}/${config.maven_rootpom_directory} && mvn sonar:sonar -P${config.maven_sonar_profile} " +
           "-Dsonar.projectKey=${config.groupid}:${config.artifactid} " +
           "-Dsonar.branch=${env.BRANCH_NAME} " +
           "-Dsonar.sourceEncoding=UTF-8 " +
           "-Dsonar.projectBaseDir=${config.workspace}/${config.maven_rootpom_directory} " +
           "-Dsonar.exclusions=**/node_modules/** " +
           "-Dsonar.projectVersion=${config.version} "
        if (flag_empty_rootpom_directory > 0 ) {      
            reportTask = "target/sonar/report-task.txt"
        } else {
            reportTask = "${config.maven_rootpom_directory}/target/sonar/report-task.txt"
        }
        Sonarprops = readProperties file: "${reportTask}"
        env.SONAR_CE_TASK_URL = Sonarprops['ceTaskUrl']
    }
    } catch (error) {
        new com.scor.utils.catchFailureBuild().call(config, "maven sonar analysis")
    }
    }
}