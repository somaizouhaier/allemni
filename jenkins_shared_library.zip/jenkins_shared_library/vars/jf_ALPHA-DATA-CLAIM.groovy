def call(Map projectElementMap) {


global_var_map = [
    project_name : "ALPHA",
    sonar_gateid : "low-restriction-not-blocking",
    maven_sonar_profile : "coverage",
    node_name : "dcvprdadm04",
    build_environment : "DEV"
]

projectElementMap.each {
global_var_map << [app_name : "${it.key}"]
}

node ("${global_var_map.node_name}") {
    new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    new com.scor.utils.scmCheckout().call()
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    new com.scor.sweagle.getInfrastructureConfiguration().call(global_var_map)
    new com.scor.sweagle.getProjectInfrastructureConfiguration().call(global_var_map)
    new com.scor.sweagle.getApplicationConfiguration().call(global_var_map)
    new com.scor.docker.installDXC().call(global_var_map)
    new com.scor.docker.version().call(global_var_map)
    new com.scor.docker.buildDisplayName().call(global_var_map)
    new com.scor.docker.login().call(global_var_map)
    new com.scor.docker.build().call(global_var_map, projectElementMap)
    new com.scor.docker.tag().call(global_var_map, projectElementMap)
    new com.scor.docker.push().call(global_var_map, projectElementMap)
    new com.scor.infrastructure.ansible.container.dockerSingleApp().call(global_var_map)
    new com.scor.utils.influxdb().record(global_var_map)
    new com.scor.utils.mail().send(global_var_map)
    }
}
