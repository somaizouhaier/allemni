package com.scor.sweagle

def call(String project, String environment) {
  node ('dcvprdadm03'){

  sweagleUrl="http://dcvprdsweagle.eu.scor.local"
  sweagleToken="9fdbb548-647a-45d4-b20e-3a5a419f1917"
  currentBuild.displayName = "${project}-${environment}"

stage("Create Sweagle Users") {

  def file_in_workspace = inputGetFile('user_upload')
  def user_account
  def user_name
  def user_email
  def user_accessType
  def user_password = "tobeupdated"

 readFile("user_upload").split('\n').each { line ->
   println line
   (user_account, user_name, user_email, user_accessType) = line.split(';')
        try {
          sh (returnStdout: true, script:"curl --max-time 3 \"${sweagleUrl}/api/v1/user\" -i -X POST -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" -d \"username=${user_account}&email=${user_email}&name=${user_name}&disabled=false&password=${user_password}&userType=PERSON\" && exit 0")
        } catch (error) {
        // ...
        }
 }
}
stage("Assign Role to sweagle User") {
  readFile("user_upload").split('\n').each { line ->
    (user_account, user_name, user_email, user_accessType) = line.split(';')
    //stage ("Retrieve Sweagle role Id for ${project}_${environment}_${accessType} and add user ") {
      try {
      def roleId 
      def userId
      roleId = sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/tenant/role\" -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" | jq \'.entities[].properties | {name: .name, id: .id} | select(.name==\"${project}_${environment}_${user_accessType}\") | .id\'").trim()
      userId = sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/user\" -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" | jq \'.entities[].properties | {username: .username, id: .id} | select(.username==\"${user_account}\") | .id\'").trim()
      sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/user/${userId}/assignRoles\" -i -X POST -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" -d \"roles=${roleId}\"")
      } catch (error) {
      unstable(message : "error while Retrieving Sweagle role and user Id for ${project}_${environment}_${user_accessType}")
      }
  }
}
} //end node
} // end call

def inputGetFile(String savedfile = null) {
  def filedata = null
    def filename = null

    if (savedfile == null) {
        def inputFile = input message: 'Upload file', parameters: [file(name: 'library_data_upload'), string(name: 'filename', defaultValue: 'upload.csv')]
        filedata = inputFile['library_data_upload']
        filename = inputFile['filename']
    } else {
        def inputFile = input message: 'Upload file', parameters: [file(name: 'library_data_upload')]
        filedata = inputFile
        filename = savedfile
    }

    writeFile(file: filename, encoding: 'Base64', text: filedata.read().getBytes().encodeBase64().toString())
    // Remove the file from the master to avoid stuff like secret leakage
    //filedata.delete()
    return filename
}
