package com.scor.maven

def call (Map config) {
	stage ('Maven Docker build') {
	try {
    if (config.containsKey('maven_package_profile')) { 
    sh "cd ${config.pompath} && chmod 700 ${config.pompath}/mvnw && ${config.pompath}/mvnw -f ${config.pompath}/pom.xml clean verify " +
	"jib:dockerBuild " +
    "-P${config.maven_package_profile}"
	} else {
    sh "cd ${config.pompath} && chmod 700 ${config.pompath}/mvnw && ${config.pompath}/mvnw -f ${config.pompath}/pom.xml clean verify " +
	"jib:dockerBuild "
    } } catch (error) {
        new com.scor.utils.catchFailureBuild().call(config, "Maven Docker build")
        }
    }
}
