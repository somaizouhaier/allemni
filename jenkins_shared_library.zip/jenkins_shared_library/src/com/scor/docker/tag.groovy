package com.scor.docker

def call(Map config, Map projectElementMap) {
  stage ('Docker tag') {
    project = config.project_name.toLowerCase()
    version = config.version.trim()
    if ("${config.branchName.contains("master")}" == "true") {
      projectElementMap.each {
        sh "docker pull ${config.artifactoryHost}/${project}/${it.key}:develop-latest"
        sh "docker tag ${config.artifactoryHost}/${project}/${it.key}:develop-latest ${config.artifactoryHost}/${project}/${it.key}:master-${version}"
        sh "docker tag ${config.artifactoryHost}/${project}/${it.key}:master-${version} ${config.artifactoryHost}/${project}/${it.key}:latest"
        config << [tag : "latest"]
      }
    } else {
      projectElementMap.each {
      sh "docker tag  ${it.key}:develop-${version} ${config.artifactoryHost}/${project}/${it.key}:develop-${version}"
      sh "docker tag  ${it.key}:develop-${version} ${config.artifactoryHost}/${project}/${it.key}:develop-latest"
      config << [tag : "develop-${version}"]
      }
    }
  }
}
