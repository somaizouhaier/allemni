package com.scor.databricks

def call(Map config) {
   stage ("Databricks cluster restart") {
        try {       
        sh "databricks clusters restart --cluster-id ${config.clusterid} --profile ${config.project_name}-${config.environment}"
        } catch (error) {
                throw (error)
        }
   }
}