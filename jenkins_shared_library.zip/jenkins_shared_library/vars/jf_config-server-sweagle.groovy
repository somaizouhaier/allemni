def call() {


global_var_map = [
    project_name : "REINS",
    sonar_gateid : "low-restriction-not-blocking",
    maven_sonar_profile : "coverage",
    maven_rootpom_directory : "",
    mavenPomNameAnchor : "artifactId",
    node_name : "dcvprdadm04",
    build_environment : "DEV"
]

node ("${global_var_map.node_name}") {
    List javaEnv = new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    withEnv(javaEnv) {
    new com.scor.utils.scmCheckout().call()
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    new com.scor.maven.updateConfiguration().call(global_var_map)
    new com.scor.docker.version().call(global_var_map)
    new com.scor.docker.buildDisplayName().call(global_var_map)
    new com.scor.maven.scanJar().call(global_var_map)
    new com.scor.maven.dockerCodeAnalyser().call(global_var_map)
    new com.scor.docker.login().call(global_var_map)
    new com.scor.maven.jarParallelLauncher().call(global_var_map, "call_dockerMavenTag", "Docker Maven Tag" )
    new com.scor.maven.jarParallelLauncher().call(global_var_map, "call_dockerMavenPush", "docker Maven Push")
    new com.scor.sweagle.getInfrastructureConfiguration().call(global_var_map)
    new com.scor.maven.jarParallelLauncher().call(global_var_map, "call_sweagleGetConfiguration", "sweagle Get Configuration")
    new com.scor.docker.installDXC().call(global_var_map)
    new com.scor.maven.jarParallelLauncher().call(global_var_map, "call_infrastructureAnsibleContainerDockerMaven", "infrastructure Ansible Container Docker Maven")
    new com.scor.utils.influxdb().record(global_var_map)
    new com.scor.utils.mail().send(global_var_map)
    }
}
}
