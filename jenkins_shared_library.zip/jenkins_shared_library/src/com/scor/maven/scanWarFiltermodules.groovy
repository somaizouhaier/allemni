package com.scor.maven

def call (Map fullmapmodule, Map warmapmodule) {
    fullmapmodule.each { module, pompath ->
        modulePomfile = readMavenPom file: "${pompath}"
        if ("${modulePomfile.packaging}" == "war") {
            if ("${modulePomfile.properties.tobedeployed}" != "false") {
                warmapmodule.put("${module}", "${pompath}")
            }
        }
    }
}
return warmapmodule