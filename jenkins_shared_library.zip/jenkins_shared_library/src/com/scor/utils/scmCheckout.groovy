package com.scor.utils

def call() {
    stage ('Source Code Manager Checkout') {
       checkout scm
    }
}