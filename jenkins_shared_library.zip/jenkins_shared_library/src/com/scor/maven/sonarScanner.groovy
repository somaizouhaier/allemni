package com.scor.maven

def call(Map config) {
       stage('Sonar Analysis') {
	try {
	withSonarQubeEnv('SonarQube-PRD') {
		sh "export SONAR_USER_HOME=/scor/delivery/sonar_cache && mvn initialize sonar:sonar"
        def Sonarprops = readProperties file: 'target/sonar/report-task.txt'
        env.SONAR_CE_TASK_URL = Sonarprops['ceTaskUrl']
    }
    } catch (error) {
        new com.scor.utils.catchFailureBuild().call(config, "maven sonar analysis")
    }
    }
}