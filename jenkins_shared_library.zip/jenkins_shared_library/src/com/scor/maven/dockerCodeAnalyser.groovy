package com.scor.maven

def call(Map config) {

    if ("${config.build_environment.contains("${config.environment}")}" == "true") {
            if ("${config.branchName.contains("master")}" == "false") {
            if (new com.scor.utils.conditionalinput().call(config, "Perform Sonar analysis ?") == true) {
                new com.scor.maven.codeAnalyserUnitTest().call(config)
                //new com.scor.maven.codeAnalyser().callIntegrationTest(config)
                new com.scor.maven.dockerCodeAnalyserSonarAnalysis().call(config)
                new com.scor.sonar.sonarQualitygate().call(config)
            }
        } 
    }
    if ("${config.branchName.contains("master")}" == "false") {
    new com.scor.maven.dockerBuildArtifactory().call(config)
    }
}

