package com.scor.sweagle

def call (Map config) {
stage ("Ansible Sweagle Azure Linux VM: ${config.project_name} ${config.environment}") {
    try {
        dir ("${config.ansible_playbook_dir}/sweagle/ansible-playbooks-sweagle") {
        create_template = sh (
        script: "source deactivate; ansible-playbook playbook_sweagle_create_template_azurevm_linux.yml -e app_name=${config.project_name} -e env=${config.environment} -e resource_group_name=${config.resource_group_name} -e subscription_id=${config.subscription_id} -e vnet_name=${config.vnet_name} -e vnet_resource_group=${config.vnet_resource_group} -e subnet_name=${config.subnet_name} -e tag_kpe='\"${config.tag_kpe}\"' -e tag_dxc_autodeploy=${config.tag_dxc_autodeploy} -e tag_dxc_patching=${config.tag_dxc_patching} -e tag_business_unit='\"${config.tag_business_unit}\"' -e tag_owner=${config.tag_owner} -e tag_data_classification=${config.tag_data_classification} -e tag_dxc_autoshutdown=${config.tag_dxc_autoshutdown} -e private_ip_address='\"${config.private_ip_address}\"' -e image_version=${config.image_version} -e vmsize=${config.vmsize}",
        returnStdout: true )
        create_sweagle_structure = sh (
        script: "ansible-playbook playbook_sweagle_create_structure.yml -e project_name=${config.project_name} -e env=${config.environment} -e sweagle_url=${config.sweagleUrl} -e token=${config.sweagleToken} -e azurevm=true -e linux=true",
        returnStdout: true )
        status = sh (
        script: "ansible-playbook playbook_sweagle_upload_files.yml -e sweagle_url=${config.sweagleUrl} -e token=${config.sweagleToken} -e '{\"files\":[{\"name\": \"azurevm_linux_vars.yml\", \"sweagle_path\": \"infrastructure,ansible,azure,vm,vars,${config.project_name},${config.environment}\", \"file_path\": \"/scor/delivery/sweagle/infrastructure/ansible/azure/vm/vars/${config.project_name}/${config.environment}\", \"format\": \"YAML\"}]}'",
        returnStatus: true
        )
        //}
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible Sweagle Azure Linux VM: ${config.project_name} ${config.environment}"]
        }
        else if ("${status}" == "0") { 
            pull_include = sh (
            script: "ansible-playbook playbook_sweagle_pull_include.yml -e project_name=${config.project_name} -e env=${config.environment} -e sweagle_url=${config.sweagleUrl} -e token=${config.sweagleToken} -e azurevm=true",
            returnStdout: true )
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible Sweagle Azure Linux VM: ${config.project_name} ${config.environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible Sweagle Azure Linux VM: ${config.project_name} ${config.environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
      }
      }
      finally {
        }
}
}
