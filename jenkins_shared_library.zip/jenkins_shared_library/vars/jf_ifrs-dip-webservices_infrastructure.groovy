def call() {
global_var_map = [
    project_name : "DIP",
    node_name : "dcvprdadm04",
]

node ("${global_var_map.node_name}") {
    //add global tool and path
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    new com.scor.sweagle.getProjectInfrastructureConfiguration().call(global_var_map)
    new com.scor.infrastructure.ansible.monitoring().call(global_var_map)
}
}
