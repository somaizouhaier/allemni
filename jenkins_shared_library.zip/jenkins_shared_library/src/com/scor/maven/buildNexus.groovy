package com.scor.maven

def call (Map config) {
	stage ('Maven Build Nexus') {
    if ("${config.version.endsWith("SNAPSHOT")}" == "true") {
        repository = "deploy-snapshots"
    } else {
        repository = "deploy-releases"
    }
	try {
    if (config.containsKey('maven_package_profile')) { 
    sh "mvn -f ${config.pompath}/pom.xml clean deploy " +
	"-DskipTests=true " +
	"-DaltDeploymentRepository=${repository}::default::http://${config.nexus_host}:${config.nexus_port}/repository/${repository}/ " +
	"-U " +
    "-P${config.maven_package_profile}"
	} else {
    sh "mvn -f ${config.pompath}/pom.xml clean deploy " +
    "-DskipTests=true " +
    "-DaltDeploymentRepository=${repository}::default::http://${config.nexus_host}:${config.nexus_port}/repository/${repository}/ " +
    "-U "      
    } } catch (error) {
        new com.scor.utils.catchFailureBuild().call(config, "maven build nexus")
        }
    }
}