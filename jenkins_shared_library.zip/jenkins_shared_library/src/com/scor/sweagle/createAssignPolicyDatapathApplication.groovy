package com.scor.sweagle

def call(String project, String environment) {
  node ('dcvprdadm03'){

  policyList=['DataPathAccess']
  nodeList1=['application']
  nodeList2=['configuration','includes']
  accessTypeList=['reader','contributor']
  sweagleUrl="http://dcvprdsweagle.eu.scor.local"
  sweagleToken="9fdbb548-647a-45d4-b20e-3a5a419f1917"

  currentBuild.displayName = "policies ${project}_${environment}_application/configuration,includes-read|contributor - Role ${project}_${environment}_read|contributor"

  stage("create Role and add Datapath policy") {
    for (String node1 : nodeList1) {
      for (String node2 : nodeList2) {

            try {
                nodeId = sh (returnStdout: true, script:"curl -s -X GET \"${sweagleUrl}/api/v1/data/node?path=${node1},${node2},${project},${environment}\" -H \"Authorization: bearer ${sweagleToken}\" | jq \'._entities[].id\'")
            } catch (error) {
            unstable(message : "error while retrieving Sweagle node id for path ${node1}/${node2}/${project}/${environment}")
            }

        for (String accessType : accessTypeList) {
              try {
                if ("${accessType}" == 'reader') {
                  canEdit = "false"
                } else {
                  canEdit = "true"
                }
                sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/tenant/policy\" -X POST -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" -d \"type=DataPathAccess&path=${nodeId}&canEdit=${canEdit}&name=${project}_${environment}_${node1}_${node2}_${accessType}&description=${project}_${environment}_${node1}/${node2}_${accessType}\"")
              } catch (error) {
                unstable(message : "error creating policy ${project}_${environment}_${node1}_${node2}_${accessType}")
              }
        }
      }
    }
  }

stage("create Role and add Datapath policy") {
    for (String accessType : accessTypeList) {
          try {
                sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/tenant/role\" -i -X POST -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" -d \"name=${project}_${environment}_${accessType}&description=${project}_${environment}_${accessType}\"")
            } catch (error) {
                throw (error)
            }

      for (String node1 : nodeList1) {
        for (String node2 : nodeList2) {
            try {
                policyId = sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/tenant/policy\" -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" | jq \'.entities[].properties | {name: .name, id: .id} | select(.name==\"${project}_${environment}_${node1}_${node2}_${accessType}\") | .id\'").trim()
                dataChangeSetApprovalPolicyId = sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/tenant/policy\" -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" | jq \'.entities[].properties | {name: .name, id: .id} | select(.name==\"Data Changeset Approval Policy\") | .id\'").trim()
                snapshotCalculationAccessId = sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/tenant/policy\" -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" | jq \'.entities[].properties | {name: .name, id: .id} | select(.name==\"Snapshot Calculation access\") | .id\'").trim()
            } catch (error) {
              unstable(message : "error while retrieving Sweagle policy Id for ${project}_${environment}_${node1}_${node2}_${accessType}")
            }

              try {
                  roleId = sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/tenant/role\" -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" | jq \'.entities[].properties | {name: .name, id: .id} | select(.name==\"${project}_${environment}_${accessType}\") | .id\'").trim()
              } catch (error) {
                  unstable(message : "error while retrieving Sweagle role Id for ${project}_${environment}_${accessType}")
              }   
          
              try {
                 sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/tenant/role/${roleId}/policies\" -X POST -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" -d \"policies=${policyId}\"")
                    if ("${accessType}" == 'contributor') {
                      sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/tenant/role/${roleId}/policies\" -X POST -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" -d \"policies=${dataChangeSetApprovalPolicyId}\"")
                      sh (returnStdout: true, script:"curl \"${sweagleUrl}/api/v1/tenant/role/${roleId}/policies\" -X POST -H \"Authorization: bearer ${sweagleToken}\" -H \"Accept: application/vnd.siren+json\" -d \"policies=${snapshotCalculationAccessId}\"")
                    } else {
                    }    
              } catch (error) {
                unstable(message : "error while adding Sweagle policy ${project}_${environment}_${node1}_${node2}_${accessType} in role ${project}_${environment}_${accessType}")
              }
        }   
      }
    }
  }

}  //close node
} //close call