def call(String version) {
global_var_map = [
    project_name : "ESSOR",
    application : "ESSOR",
    sonar_gateid : "low-restriction-not-blocking",
    maven_sonar_profile : "coverage",
    maven_rootpom_directory : "",
    mavenPomNameAnchor : "artifactId",
    mavenPackaging : "",
    build_environment : "DEV"
]
global_var_map << [version : "${version}"]
    List javaEnv = new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    withEnv(javaEnv) {
    new com.scor.utils.scmCheckout().call()
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    new com.scor.utils.buildDisplayName().call(global_var_map)
    new com.scor.sonar.sonarScanner().call(global_var_map)
    }
}