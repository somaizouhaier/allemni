package com.scor.nexus

def call(Map config) {
        stage ("Retrieve from Nexus ${config.assemblyArtifactId}") {
                try {
                        sh "[[ -d /scor/delivery/Nexus_download/${config.project_name}/${config.assemblyArtifactId}/${config.environment}/${config.assemblyExtension} ]] || mkdir -p /scor/delivery/Nexus_download/${config.project_name}/${config.assemblyArtifactId}/${config.environment}/${config.assemblyExtension}"
                        sh "${config.nexus_shell_dir}/retrieveFromNexus/RetrieveFromNexusClassifier.sh ${config.groupid} ${config.assemblyArtifactId} ${config.version} /scor/delivery/Nexus_download/${config.project_name}/${config.assemblyArtifactId}/${config.environment}/${config.assemblyExtension} ${config.nexus_host} ${config.nexus_port} ${config.assemblyExtension} ${config.assemblyArtifactId} ${config.assemblyClassifier}"
                        sh "cd /scor/delivery/Nexus_download/${config.project_name}/${config.assemblyArtifactId}/${config.environment}/${config.assemblyExtension} && tar xvf /scor/delivery/Nexus_download/${config.project_name}/${config.assemblyArtifactId}/${config.environment}/${config.assemblyExtension}/${config.assemblyArtifactId}.${config.assemblyExtension}"
                } catch (error) {
                throw (error)
                }
        }
}