package com.scor.databricks

def call(Map config) {
   stage ("Databricks import ${config.assemblyArtifactId}") {
        try {       
        sh "databricks workspace import_dir -o /scor/delivery/Nexus_download/${config.project_name}/${config.assemblyArtifactId}/${config.environment}/${config.assemblyExtension} ${config.databricksImportDir} --profile ${config.project_name}-${config.environment}"
        } catch (error) {
                throw (error)
        }
   }
}