package com.scor.docker

def call(Map config, String finalName, String groupId, String artifactId, String module) {
  stage ('Docker tag') {
    project = config.project_name.toLowerCase()
    version = config.version.trim()
    if ("${config.branchName.contains("master")}" == "true") {
        sh "docker pull ${config.artifactoryHost}/${project}/${config.pomFileMavenPomNameAnchor}:develop-latest"
        sh "docker tag ${config.artifactoryHost}/${project}/${finalName}:develop-latest ${config.artifactoryHost}/${project}/${finalName}:master-${version}"
        sh "docker tag ${config.artifactoryHost}/${project}/${finalName}:master-${version} ${config.artifactoryHost}/${project}/${finalName}:latest"
        config << [tag : "latest"]
    } else {
      sh "docker tag  ${finalName}:currentbuild ${config.artifactoryHost}/${project}/${finalName}:develop-${version}"
      sh "docker tag  ${config.artifactoryHost}/${project}/${finalName}:develop-${version} ${config.artifactoryHost}/${project}/${finalName}:develop-latest"
      config << [tag : "develop-${version}"]
    }
  }
}
