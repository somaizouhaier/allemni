def call(String project, String environment) {
    new com.scor.sweagle.createAssignPolicyDatapathApplication().call("${project}", "${environment}")
}