package com.scor.maven

def call(Map config, String function_name, String stage_name) {

//DOCUMENTATION !!

    def stepsForParallel = config.warmapmodule.collectEntries { module, pompath ->
    ["${module}" : new com.scor.maven.transformIntoStep().call(module, "${pompath}", "${function_name}", config)]
    }

    stage ("${stage_name}") {
    parallel stepsForParallel   
    }
}
