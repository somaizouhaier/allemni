package com.scor.sonar

def call(Map config) {       
       stage('Sonar Analysis') {
	try {
        def scannerHome = tool name: 'sonar-scanner'
	//withSonarQubeEnv('SonarQube-PRD') {
		sh "export SONAR_USER_HOME=/scor/delivery/sonar_cache && ${scannerHome}/bin/sonar-scanner "
        def Sonarprops = readProperties file: 'target/sonar/report-task.txt'
        env.SONAR_CE_TASK_URL = Sonarprops['ceTaskUrl']
    //}
    } catch (error) {
        new com.scor.utils.catchFailureBuild().call(config, "maven sonar analysis")
    }
    }
}