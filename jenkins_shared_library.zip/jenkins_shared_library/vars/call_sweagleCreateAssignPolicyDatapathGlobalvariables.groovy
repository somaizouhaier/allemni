def call(String project, String environment) {
    new com.scor.sweagle.createAssignPolicyDatapathGlobalvariables().call("${project}", "${environment}")
}