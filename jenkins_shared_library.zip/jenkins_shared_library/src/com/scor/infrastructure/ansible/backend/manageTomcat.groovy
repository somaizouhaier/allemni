package com.scor.infrastructure.ansible.backend

def call (String project, String application, String environment, String tags) {
stage ("Ansible Backend Tomcat ${project} ${application} ${environment} ${tags}") {
    try {
        dir ("/scor/CI-Factory/ansible/playbooks/backend/tomcat") {
        status = sh (
        script: "ansible-playbook -i /scor/delivery/sweagle/infrastructure/ansible/backend/tomcat/host/${project}/${environment}/${application}/tomcat_host.yml /scor/CI-Factory/ansible/playbooks/backend/tomcat/playbook_tomcat.yml -e project_name=${project} -e env=${environment} -e app_name=${application} -e group_hosts=${application} --tags ${tags}", 
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
        }
        else {
                currentBuild.result = "FAILURE"
        throw (error)
        }
     } finally {
        }
}
}