#!/bin/sh

groupId=$1
artifactId=$2
version=$3
download_repo=$4
Nexus_host=$5
Nexus_port=$6

nexus_user=deployment
nexus_password=ScorNexus123%

repo="http://"$Nexus_host":"$Nexus_port""
# optional
type=$7
finalName=$8
if [[ $type == "" ]]; then
  type="war"
fi

if [[ $finalName == "" ]]; then
  finalName="${artifactId}"
fi
classifier="-$9"



groupIdUrl="${groupId//.//}"
filename="${finalName}-${version}.${type}"
filenameNoVersion="${finalName}.${type}"

if [[ ${version} == *"SNAPSHOT"* ]]; then repo_type="snapshots"; else repo_type="releases"; fi

if [[ $repo_type == "releases" ]]
 then
   export no_proxy="$Nexus_host" && wget --user $nexus_user --password $nexus_password --no-check-certificate "${repo}/repository/deploy-releases/${groupIdUrl}/${artifactId}/${version}/${artifactId}-"${version}""${classifier}".${type}" -O ${download_repo}/${filenameNoVersion}
 else
   export no_proxy="$Nexus_host" && versionTimestamped=$(wget --user $nexus_user --password $nexus_password -q -O- --no-check-certificate "${repo}/repository/deploy-snapshots/${groupIdUrl}/${artifactId}/${version}/maven-metadata.xml" | grep -m 1 \<value\> | sed -e 's/<value>\(.*\)<\/value>/\1/' | sed -e 's/ //g')
   export no_proxy="$Nexus_host" && wget --user $nexus_user --password $nexus_password --no-check-certificate "${repo}/repository/deploy-snapshots/${groupIdUrl}/${artifactId}/${version}/${artifactId}-"${versionTimestamped}""${classifier}".${type}" -O ${download_repo}/${filenameNoVersion}
 fi