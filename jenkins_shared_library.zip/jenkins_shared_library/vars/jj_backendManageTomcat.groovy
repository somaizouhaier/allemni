def call(Map config) {
node ('dcvprdadm04') {
currentBuild.displayName = "${config.project}-${config.environment}-${config.application}-${config.tag}"
new com.scor.infrastructure.ansible.backend.manageTomcat().call("${config.project}", "${config.application}", "${config.environment}", "${config.tag}")
}
}