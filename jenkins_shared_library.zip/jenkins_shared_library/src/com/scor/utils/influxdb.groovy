package com.scor.utils

def record (Map config) {
	try {
		step(
			[$class: 'InfluxDbPublisher',
			customData: null, 
			customDataMap: null, 
			customPrefix: "${config.project_name}_${config.environment}", 
			target: 'influxdb']
			)
	} catch (error) {
		new com.scor.utils.catchFailureBuild().call(config, "influxdb.record")
	}
}
return this;