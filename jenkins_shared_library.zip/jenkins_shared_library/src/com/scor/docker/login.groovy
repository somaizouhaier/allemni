package com.scor.docker

def call(config) {
    sh "docker login -u ${config.dockerUser} -p ${config.dockerPassword} ${config.artifactoryHost}" 
}