package com.scor.nexus

def call(Map config, String finalName, String groupId, String artifactId, String module) {
        try {
        sh "[[ -d /scor/delivery/Nexus_download/${config.project_name}/${finalName}/${config.environment}/jar ]] || mkdir -p /scor/delivery/Nexus_download/${config.project_name}/${finalName}/${config.environment}/jar"
        sh "${config.nexus_shell_dir}/retrieveFromNexus/RetrieveFromNexus.sh ${groupId} ${artifactId} ${config.version} /scor/delivery/Nexus_download/${config.project_name}/${finalName}/${config.environment}/jar ${config.nexus_host} ${config.nexus_port} jar ${finalName}"
        } catch (error) {
                throw (error)
        }
}