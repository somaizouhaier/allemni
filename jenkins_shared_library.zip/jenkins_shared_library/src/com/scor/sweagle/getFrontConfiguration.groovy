package com.scor.sweagle

def call (Map config) {
if ("${config.maven_frontpom_directory}" == "") {
    frontpom = readMavenPom file: "pom.xml"
} else {
    frontpom = readMavenPom file: "${config.maven_frontpom_directory}/pom.xml"
}

    stage ("Sweagle Get ${frontpom.build.finalName} Configuration") {
    try {
        sh "${config.sweagle_shell_dir}/retrieve_all_configuration/scorGetConfigByAppEnvrt.sh ${config.project_name} ${config.environment} ${frontpom.build.finalName} ${config.sweagle_stored_dir}"
     } catch (error) {
        new com.scor.utils.catchFailureBuild().call(config, "sweagle get front configuration")
            }
    }
}