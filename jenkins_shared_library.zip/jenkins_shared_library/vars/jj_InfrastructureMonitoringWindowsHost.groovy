def call(Map config) {
node ('dcvprdadm04') {
new com.scor.utils.setGlobalConfiguration().call(config)
new com.scor.utils.setProjectName().call(config)
currentBuild.displayName = "${config.environment}-${BUILD_NUMBER}"
new com.scor.infrastructure.ansible.monitoring.monitoring_host_windows().call(config)
}
}
