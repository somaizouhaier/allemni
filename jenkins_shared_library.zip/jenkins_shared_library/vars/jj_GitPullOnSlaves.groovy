def call(Map config) {
new com.scor.git.gitPullTFSOnSlaves().call(config)
}