package com.scor.sweagle

def call (Map config, String componentName) {
    Map params = [
            stepName : "Ansible Sweagle Copy tree ${config.project} ${config.application} from ${config.environment} to ${config.new_environment} ${componentName}",
            ansiblePlaybookDir : "${config.ansible_playbook_dir}/sweagle/ansible-playbooks-sweagle",
            script : "ansible-playbook playbook_sweagle_copy_metadata_set.yml -e project_name=${config.project} -e env=${config.environment} -e app_name=${config.application} -e sweagle_url=${config.sweagleUrl} -e token=${config.sweagleToken} -e ${componentName}=true -e new_env=${config.new_environment}"
    ]

    new com.scor.utils.ansiblePlaybookRun().call(config, params)


}