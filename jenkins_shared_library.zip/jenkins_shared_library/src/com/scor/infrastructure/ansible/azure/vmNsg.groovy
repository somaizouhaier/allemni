package com.scor.infrastructure.ansible.azure

def call (Map config, String open) {
stage ("Ansible Azure VM NSG open : ${open}") {
    try {
        dir ("${config.ansible_playbook_dir}/azure/ansible-playbooks-azure") {
        status = sh (
        script: "ansible-playbook playbook_azure_nsg_rules.yml -e env=${config.environment} -e app_name=${config.project_name} -e open=${open}",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "infrastructure ansible Azure VM NSG to ${open}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "infrastructure ansible Azure VM NSG to ${open}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "infrastructure ansible Azure VM NSG to ${open}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
}
}
