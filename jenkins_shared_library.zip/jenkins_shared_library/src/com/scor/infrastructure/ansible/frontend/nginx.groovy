package com.scor.infrastructure.ansible.frontend

def call (Map config) {
if ("${config.maven_frontpom_directory}" == "") {
    frontpom = readMavenPom file: "pom.xml"
} else {
    frontpom = readMavenPom file: "${config.maven_frontpom_directory}/pom.xml"
}
stage ("Ansible Frontend Nginx ${frontpom.build.finalName}") {
    try {
        dir ("${config.ansible_playbook_dir}/frontend/nginx") {
        status = sh (
        script: "ansible-playbook -i ${config.sweagle_stored_dir}/infrastructure/ansible/frontend/nginx/host/${config.project_name}/${config.environment}/${frontpom.build.finalName}/nginx_host.yml playbook_nginx.yml -e project_name=${config.project_name} -e app_version=${frontpom.version} -e env=${config.environment} -e app_name=${frontpom.build.finalName} -e app_groupid=${frontpom.groupId} -e app_artifactid=${frontpom.artifactId} -e group_hosts=${frontpom.artifactId} -e app_extension=tar -e app_classifier=front",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "infrastructure ansible frontend nginx ${frontpom.build.finalName}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "infrastructure ansible frontend nginx ${frontpom.build.finalName}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "infrastructure ansible frontend nginx ${frontpom.build.finalName}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
}
}
