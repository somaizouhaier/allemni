package com.scor.docker

def call(Map config, Map projectElementMap) {
if ("${config.branchName}" == "master") {
  //...
  } else {
    stage ('Docker build') {
      project = config.project_name.toLowerCase()
      version = config.version.trim()
      projectElementMap.each {
        sh "docker build -t ${it.key}:develop-${version} ${it.value}"
      }
    }
  }
}
