package com.scor.maven

def call(String module, String pomPath, String step, Map config) {
    return {
        node ("${config.node_name}") {
            def pomFile = readMavenPom file: "${pomPath}"
            def pomFileGroupId
            def pomFileMavenPomNameAnchor

            if (("${pomFile.groupId}" == 'null') && ("${pomFile.parent.groupId}" == 'null')) {
				error"[ERROR] no groupId defined in pom ${pomPath}/pom.xml"
			}
			if ("${pomFile.groupId}" == 'null') {
				pomFileGroupId = "${pomFile.parent.groupId}"
			} else {
				pomFileGroupId = "${pomFile.groupId}"
			}

			if ("${config.mavenPomNameAnchor}" == "finalName") {
    			pomFileMavenPomNameAnchor = "${pomFile.build."${config.mavenPomNameAnchor}"}"
    		} else {
    			pomFileMavenPomNameAnchor = "${pomFile."${config.mavenPomNameAnchor}"}"
    		}

    		def requiredVariableList = [
    			pomFileGroupId : "${pomFileGroupId}", 
    			pomFileArtifactid : "${pomFile.artifactId}", 
    			mavenPomNameAnchor : "${config.mavenPomNameAnchor}",
    			pomFileMavenPomNameAnchor : "${pomFileMavenPomNameAnchor}"
    		]
   			requiredVariableList.each { variable_name, variable_value ->
				if ("${variable_value}" == 'null') {
    				error"[error] The variable ${variable_name} is not defined"
				}
			}
            stage (module) {
				//"${step}"(config, application name, groupID, artifactId, module name)
				"${step}"(config, "${pomFileMavenPomNameAnchor}", "${pomFileGroupId}", "${pomFile.artifactId}", "${module}")
			}
        }
    }
}