package com.scor.utils

def call (Map config) {
	//required variables in entry map:
	// - application
	// - environment
	// - version
	currentBuild.displayName = "${config.application}-${config.environment}-${env.BRANCH_NAME}-${config.version}"
}