def call() {
global_var_map = [
    project_name : "In_IT_we_trust",
    sonar_gateid : "low-restriction-not-blocking",
    maven_sonar_profile : "coverage",
    maven_rootpom_directory : "",
    ansible_playbook_dir : "/scor/CI-Factory/ansible/playbooks",
    node_name : "dcvprdadm04",
    build_environment : "DEV"
]

node ("${global_var_map.node_name}") {
    List javaEnv = new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    withEnv(javaEnv) {
        stage ('Get Jenkinsfile')
        {
            checkout scm
            try
            {
                Cur_version = "0.0.1-test"
                println "${Cur_version}"

                scriptName="$workspace/build.sh"
                scriptContent = libraryResource "${scriptName}"
                writeFile file: "${scriptName}", text: scriptContent
                sh "chmod +x ${scriptName}"

            }
            catch (error)
            {
                if (!binding.hasVariable('Cur_version'))
                {
                    Cur_version = "NOT FOUND"
                }
            }
        }
        
        stage ('Build docker image')
        {
        sh "docker build --pull --file ${workspace}/Dockerfile --tag ${Cur_version} ${workspace}"
        }
        stage ('publish docker image to artifactory')
        {
            sh "cd ${workspace}"
            sh "docker login --username norma-dev-upload --password Ws1Gu5Fr5Uw_Dh3C norma-docker-dev.artifactory.eu.scor.local"
            sh "docker tag ${Cur_version} norma-docker-dev.artifactory.eu.scor.local/${Cur_version}"
            sh "docker push norma-docker-dev.artifactory.eu.scor.local/${Cur_version}"
        }


        stage ('pull and launch docker image')
        {
            images = sh (returnStdout: true, script: "docker ps -q")
            tag = "${Cur_version}"
            sh "sudo -u tomcat ssh u006252@10.16.36.6 'docker pull norma-docker-dev.artifactory.eu.scor.local/$tag'"
            sh "sudo -u tomcat ssh u006252@10.16.36.6 'docker run -d -p 4444:4444 norma-docker-dev.artifactory.eu.scor.local/$tag'"
        }

    }
}
}

