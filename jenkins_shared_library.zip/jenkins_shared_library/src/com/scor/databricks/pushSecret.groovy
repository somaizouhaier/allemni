package com.scor.databricks

def call(Map config, String application) {
   stage ("Databricks push secret") {
        try {
        sh "${config.databricks_shell_dir}/commands/pushsecret.sh ${config.sweagle_stored_dir} ${config.project_name} ${config.environment} ${application} ${config.databricksScope}"
        } catch (error) {
                throw (error)
        }
   }
}