package com.scor.maven

def call (Map config) {

//Check if we are building a tag or a branch
tagName = env.TAG_NAME
branchName = env.BRANCH_NAME
step = "release version control"
 
    def releaseversion=false
    if (branchName.equals(tagName)) {
    releaseversion=true
    }

    if ("${config.version.endsWith("SNAPSHOT")}" == "false") {
        if ("${releaseversion}" != "true") {
            stage ('release version control'){
            echo "Launch a release version without tag is not allowed, please generate a tag"
            currentBuild.result = "FAILURE"
            config << [status : "${currentBuild.result}", step : "release version control"]
            new com.scor.utils.mail().send(config)
            throw (error)
            } 
        } 
    }
 
    if ("${config.version.endsWith("SNAPSHOT")}" == "true") {
        if ("${releaseversion}" == "true") {
            stage ('release version control'){
            echo "Launch a snapshot version within a tag is not allowed, please modify the version of your tag"
            currentBuild.result = "FAILURE"
            config << [status : "${currentBuild.result}", step : "release version control"]
            new com.scor.utils.mail().send(config)
            throw (error)
            } 
        } 
    }
return releaseversion
}
