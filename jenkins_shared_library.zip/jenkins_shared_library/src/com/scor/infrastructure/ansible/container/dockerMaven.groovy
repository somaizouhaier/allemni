package com.scor.infrastructure.ansible.container

def call (Map config, String finalName, String groupId, String artifactId, String module) {
stage ("Ansible Container Docker Maven") {
    try {
        def ansible_playbook_dir = "/scor/CI-Factory/ansible/playbooks"
        dir ("${ansible_playbook_dir}/container/ansible-playbooks-docker") {
        status = sh (
        script: "sed -i '2iversion: \\\"2\\\"' /scor/delivery/sweagle/infrastructure/ansible/container/docker/vars/${config.project_name}/${config.environment}/${finalName}/docker-compose.yml;ansible-playbook playbook_docker_compose_single_app.yml -i /scor/delivery/sweagle/infrastructure/ansible/container/docker/host/${config.project_name}/${config.environment}/docker_host.yml -e project_name=${config.project_name} -e app_name=${finalName} -e env=${config.environment} -e group_hosts=docker -e tag=${config.tag}",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible Container Docker: ${config.project_name} ${config.environment}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible Container Docker: ${config.project_name} ${config.environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible Container Docker: ${config.project_name} ${config.environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
    }
}
