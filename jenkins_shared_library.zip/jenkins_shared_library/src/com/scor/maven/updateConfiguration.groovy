package com.scor.maven

def call (Map globalVarMap) {

	def rootPomPath = "${workspace}/${globalVarMap.maven_rootpom_directory}"
    
    def rootpom = readMavenPom file: "${rootPomPath}/pom.xml"
    def flagVersion = 0
    def rootPomMavenPomNameAnchor
    def rootPomGroupId

    if ("${globalVarMap.mavenPomNameAnchor}" == "finalName") {
    	rootPomMavenPomNameAnchor = "${rootpom.build."${globalVarMap.mavenPomNameAnchor}"}"
    } else {
    	rootPomMavenPomNameAnchor = "${rootpom."${globalVarMap.mavenPomNameAnchor}"}"
    }

    if ("${rootpom.groupId}" != 'null') {
    	rootPomGroupId = "${rootpom.groupId}"
    } else if ("${rootpom.parent.groupId}" != 'null') {
		rootPomGroupId = "${rootpom.parent.groupId}"
	}

    def requiredVariableList = [
    	rootPomGroupId : "${rootPomGroupId}", 
    	rootPomArtifactid : "${rootpom.artifactId}", 
    	rootPomPath : "${workspace}/${globalVarMap.maven_rootpom_directory}",
    	mavenPomNameAnchor : "${globalVarMap.mavenPomNameAnchor}",
    	rootPomMavenPomNameAnchor : "${rootPomMavenPomNameAnchor}"
    ]
   	requiredVariableList.each { variable_name, variable_value ->
		if ("${variable_value}" == 'null') {
    		error"[ERROR] the variable ${variable_name} is not defined : check your root pom file, the anchor ${globalVarMap.mavenPomNameAnchor} is missing"
		}
	}

	if ( !rootPomGroupId.contains('com.scor')) {
		error"The root pom groupId is not following the standart syntax : com.scor."
	}

	if ( ( "${rootpom.version}" != 'null' ) && ( !rootpom.version.contains('${') )) {
		globalVarMap << [version : "${rootpom.version}"]
		flagVersion = flagVersion + 1;
	}
	if ( ( "${rootpom.version}" == 'null' ) && ( "${rootpom.parent.version}" != 'null' )) {
		globalVarMap << [version : "${rootpom.parent.version}"]
		flagVersion = flagVersion + 1;
	}	
	if ("${rootpom.properties.version}" != 'null') {
		globalVarMap << [version : "${rootpom.properties.version}"]
		flagVersion = flagVersion + 1;
	}
	if ("${rootpom.properties.revision}" != 'null') {
		globalVarMap << [version : "${rootpom.properties.revision}"]
		flagVersion = flagVersion + 1;
	}
	if ("${rootpom.properties.appversion}" != 'null') {
		globalVarMap << [version : "${rootpom.properties.appversion}"]
		flagVersion = flagVersion + 1;
	}	
	if ("${flagVersion}" == "0") {
		error(message: 'No version found in the pom file')
	}
	if ("${flagVersion}" > "1") {
		println "flagVersion = ${flagVersion}"
		error(message: 'More than 1 version has been found in the pom file')
	}
	if ("${flagVersion}" == "1" ) {

    globalVarMap << [application : "${rootPomMavenPomNameAnchor}"]
    globalVarMap << [pompath : "${rootPomPath}"]
    globalVarMap << [groupid : "${rootPomGroupId}"]
    globalVarMap << [artifactid : "${rootpom.artifactId}"]
	}
}