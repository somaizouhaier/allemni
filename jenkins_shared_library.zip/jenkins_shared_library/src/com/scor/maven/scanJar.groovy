package com.scor.maven

def call (Map global_var_map) {
	Map fullmapmodule = [:]
	Map jarmapmodule = [:]
    new com.scor.maven.scanJarGetmodules().call(fullmapmodule, "${global_var_map.pompath}")
    new com.scor.maven.scanJarFiltermodules().call(fullmapmodule, jarmapmodule)
	global_var_map << [fullmapmodule : fullmapmodule]
	global_var_map << [jarmapmodule : jarmapmodule]
}
