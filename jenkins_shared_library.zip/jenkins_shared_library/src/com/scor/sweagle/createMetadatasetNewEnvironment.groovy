package com.scor.sweagle

def call (Map config) {

stage ("Ansible Sweagle Create Metadataset ${config.project}_${config.new_environment}_${config.application}") {
    try {
        dir ("${config.ansible_playbook_dir}/sweagle/ansible-playbooks-sweagle") {
        status = sh (
        script: "ansible-playbook playbook_sweagle_create_metadata_set.yml -e project_name=${config.project} -e env=${config.new_environment} -e app_name=${config.application} -e sweagle_url=${config.sweagleUrl} -e token=${config.sweagleToken}", 
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
        }
        else {
                currentBuild.result = "FAILURE"
        throw (error)
        }
     } finally {
        }
}

}