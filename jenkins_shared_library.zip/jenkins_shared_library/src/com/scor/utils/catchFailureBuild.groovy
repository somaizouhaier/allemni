package com.scor.utils

def call (Map config, String stepName) {

	currentBuild.result = "FAILURE"
	config << [status : "${currentBuild.result}", step : stepName]
	new com.scor.utils.influxdb().record(config)
	new com.scor.utils.mail().send(config)
	throw (error)
}
