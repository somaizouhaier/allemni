package com.scor.docker

def call(Map config, String finalName, String groupId, String artifactId, String module) {
  stage ('Docker push'){
    project = config.project_name.toLowerCase()
    version = config.version.trim()
    if ("${config.branchName.contains("master")}" == "true") {
        sh "docker push ${config.artifactoryHost}/${project}/${finalName}:master-${version}"
        sh "docker push ${config.artifactoryHost}/${project}/${finalName}:latest"
    } else {
        sh "docker push ${config.artifactoryHost}/${project}/${finalName}:develop-${version}"
        sh "docker push ${config.artifactoryHost}/${project}/${finalName}:develop-latest"
    }
  }
}
