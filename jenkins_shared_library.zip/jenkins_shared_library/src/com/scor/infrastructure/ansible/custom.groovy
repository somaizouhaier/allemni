package com.scor.infrastructure.ansible

def call (Map config) {
if ("${config.maven_frontpom_directory}" == "") {
    frontpom = readMavenPom file: "pom.xml"
} else {
    frontpom = readMavenPom file: "${config.maven_frontpom_directory}/pom.xml"
}
stage ("Ansible Custom ${frontpom.build.finalName}") {
    try {
        dir ("${config.ansible_playbook_dir}/custom/${frontpom.build.finalName}") {
        status = sh (
        script: "ansible-playbook -i ${config.sweagle_stored_dir}/infrastructure/ansible/custom/host/${config.project_name}/${config.environment}/${frontpom.build.finalName}/custom_host.yml playbook_${frontpom.build.finalName}.yml -e project_name=${config.project_name} -e app_version=${frontpom.version} -e env=${config.environment} -e app_name=${frontpom.build.finalName} -e app_groupid=${frontpom.groupId} -e app_artifactid=${frontpom.build.finalName} -e group_hosts=${frontpom.build.finalName} -e app_extension=${config.mavenPackaging} -e app_classifier=assembly",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "infrastructure ansible frontend nginx ${frontpom.build.finalName}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "infrastructure ansible frontend nginx ${frontpom.build.finalName}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "infrastructure ansible frontend nginx ${frontpom.build.finalName}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
}
}