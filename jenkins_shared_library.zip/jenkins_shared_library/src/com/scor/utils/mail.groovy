package com.scor.utils

def send (Map config) {
    wrap([$class: 'BuildUser']) {
         emailext (
         mimeType: 'text/html',
         subject: "Pipeline ${env.JOB_NAME} ${config.status}",
         body: """
         Application : <b>${config.application}</b> <br/>
         Environment : <b>${config.environment}</b> <br/>
         GIT branch : <b>${env.BRANCH_NAME}</b> <br/>
         Version : <b>${config.version}</b> <br/>
         Pipeline Step : <b>${config.step}</b> <br/>
         Status : <b>${config.status}</b> <br/>
         Console output : <a href="${env.BUILD_URL}">Jenkins Job link</a>""",
         to: "${BUILD_USER_EMAIL}, ITPrd_Deliv@scor.com",
         from: 'CI-Factory <CI-factory@scor.com>')
    }
}
return this;