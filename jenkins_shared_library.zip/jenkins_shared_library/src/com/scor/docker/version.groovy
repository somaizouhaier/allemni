package com.scor.docker

def call (Map config) {
stage ('Retrieve version') {
	try {
          dir ("${workspace}") {
     	  docker_version = sh( script: "git rev-parse --short HEAD", returnStdout: true )
          }
        }
	catch (error) {
        new com.scor.utils.catchFailureBuild().call(config, "docker Version")
    }
    config << [version : "${docker_version}"]
}
}
