def call() {
global_var_map = [
    project_name : "ci_container",
    app_name : "ci_test",
    node_name : "dcvprdadm04",
    build_environment : "DEV"
]

node ("${global_var_map.node_name}") {
    new com.scor.utils.scmCheckout().call()
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    new com.scor.docker.login().call(global_var_map)
    if ("${global_var_map.branchName.contains("master")}" == "true") {
    new com.scor.docker.release().call(global_var_map)
    } else {
    new com.scor.docker.build().call(global_var_map)
    }
    new com.scor.infrastructure.ansible.container.docker().call(global_var_map)
}
}