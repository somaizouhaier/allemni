package com.scor.utils

def call (global_var_map) {
    def IaCfolder = ""
    if ("${global_var_map.jenkinsBranch}") {
        IaCfolder = "-${global_var_map.jenkinsBranch}"
    }

    global_var_map << [ansible_playbook_dir : "/scor/CI-Factory${IaCfolder}/ansible/playbooks"]
    global_var_map << [sweagle_stored_dir : "/scor/delivery/sweagle"]
    global_var_map << [sweagle_shell_dir : "/scor/CI-Factory${IaCfolder}/shell/sweagle"]
    global_var_map << [workspace : pwd()]
	global_var_map << [nexus_host : "10.20.1.73"]
	global_var_map << [nexus_port : "8082"]
	global_var_map << [sweagleUrl : "http://dcvprdadm03.eu.scor.local"]
	global_var_map << [sweagleToken : "9fdbb548-647a-45d4-b20e-3a5a419f1917"]
    global_var_map << [dockerUser : "u006252"]
    global_var_map << [dockerPassword : "AP7w4bTrUJ6Xw5JQtGwxp5V89vE"]
    global_var_map << [artifactoryHost : "docker.artifactory.eu.scor.local"]
    global_var_map << [ssh_keyPath: "/scor/CI-Factory${IaCfolder}/ansible/ssh_key/sshkey_list" ]
    global_var_map << [branchName : "${env.BRANCH_NAME}"]
    global_var_map << [buildNumber : "${env.BUILD_NUMBER}"]
}
