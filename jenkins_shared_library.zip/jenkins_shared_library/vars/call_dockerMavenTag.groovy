def call(Map config, String finalName, String groupId, String artifactId, String module) {
    new com.scor.docker.mavenTag().call(config,"${finalName}","${groupId}","${artifactId}","${module}")
}