package com.scor.infrastructure.ansible.azure

def call (Map config) {
stage ("Ansible Create Azure Storage Account: ${config.project_name} ${config.environment}") {
    try {
        def ansible_playbook_dir = "/scor/CI-Factory/ansible/playbooks"
        dir ("${ansible_playbook_dir}/azure/ansible-playbooks-azure") {
        status = sh (
        script: "ansible-playbook playbook_azure_create_storage_account.yml -e app_name=${config.project_name} -e env=${config.environment}",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Storage Account: ${config.project_name} ${config.environment}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Storage Account: ${config.project_name} ${config.environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible Create Azure Storage Account: ${config.project_name} ${config.environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
}
}
