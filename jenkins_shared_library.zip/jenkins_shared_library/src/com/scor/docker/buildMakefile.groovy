package com.scor.docker

def call(config) {
    stage('build docker image') {
                status = sh (
        script: "make DOCKER_REPO=${config.artifactoryHost} release",
        returnStatus: true
                )
    }	
}
