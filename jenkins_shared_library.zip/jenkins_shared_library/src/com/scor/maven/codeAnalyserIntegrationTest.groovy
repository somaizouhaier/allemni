package com.scor.maven

def call (Map config) {
	stage ('Maven Integration Tests') {
	try {
	sh "mvn -f ${config.pompath}/pom.xml failsafe:integration-test -P${config.maven_sonar_profile}"
	} catch (error) {
		new com.scor.utils.catchFailureBuild().call("maven integration tests")
		}
    }
}