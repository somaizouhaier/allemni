package com.scor.infrastructure.ansible.azure.DXC

def call (Map config) {
stage ("Ansible Create Azure Linux VM: ${config.project_name} ${config.environment}") {
    try {
        dir ("${config.ansible_playbook_dir}/azure/ansible-playbooks-azure") {
        autoshutdown = sh (
        script: 'cat ${sweagle_stored_dir}/infrastructure/ansible/azure/vm/vars/${config.project_name}/${config.environment}/azurevm_linux_vars.yml |grep tag_dxc_autoshutdown | cut -d ":" -f 2',
        returnStdout: true ).trim()
        status = sh (
        script: "ansible-playbook playbook_azure_create_dxc_server_linux.yml -e app_name=${config.project_name} -e env=${config.environment} --private-key ${config.ansible_playbook_dir}/azure/ssh_key/rootlnxazure_private_key -i ${config.ansible_config_dir}/azure/vm/${config.project_name}/${config.environment}/linux_hosts -e tag_dxc_autoshutdown=${autoshutdown}",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Linux VM: ${config.project_name} ${config.environment}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Linux VM: ${config.project_name} ${config.environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible Create Azure Linux VM: ${config.project_name} ${config.environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
      }
      finally {
        }
}
}
