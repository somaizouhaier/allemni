package com.scor.infrastructure.ansible.backend

def call (Map config, String finalName, String groupId, String artifactId, String module) {
stage ("Ansible Backend Springboot ${module}") {
    try {
        dir ("${config.ansible_playbook_dir}/backend/springboot") {
        status = sh (
        script: "ansible-playbook -i ${config.sweagle_stored_dir}/infrastructure/ansible/backend/springboot/host/${config.project_name}/${config.environment}/${finalName}/springboot_host.yml playbook_springboot.yml -e project_name=${config.project_name} -e app_version=${config.version} -e env=${config.environment} -e app_name=${finalName} -e app_groupid=${groupId} -e app_artifactid=${artifactId} -e group_hosts=${finalName} -e app_extension=\"jar\" -e app_classifier=\"exec\"", 
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "infrastructure ansible backend tomcat ${module}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "infrastructure ansible backend tomcat ${module}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "infrastructure ansible backend tomcat ${module}"]
        throw (error)
        }
     } finally {
        }
}
}