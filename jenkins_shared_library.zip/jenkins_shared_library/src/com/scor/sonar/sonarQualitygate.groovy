package com.scor.sonar

def call(Map config) {

stage("Sonar Quality Gate"){
    withSonarQubeEnv('SonarQube-PRD') {
	def numGateId = '1'
	try { 
		 if ("${config.sonar_gateid}" == "low-restriction-not-blocking") { numGateId = "15" }
	else if ("${config.sonar_gateid}" == "middle-restriction-not-blocking") { numGateId = "14" }
	else if ("${config.sonar_gateid}" == "high-restriction-not-blocking") { numGateId = "13" }
	else if ("${config.sonar_gateid}" == "very-high-restriction-not-blocking") { numGateId = "7" }
	else if ("${config.sonar_gateid}" == "low-restriction-blocking") { numGateId = "19" }
	else if ("${config.sonar_gateid}" == "middle-restriction-blocking") { numGateId = "18" }
	else if ("${config.sonar_gateid}" == "high-restriction-blocking") { numGateId = "17" }
	else if ("${config.sonar_gateid}" == "very-high-restriction-blocking") { numGateId = "12" }
	else if ("${config.sonar_gateid}" == "SonarQube-defaut") { numGateId = "1" }
 
	sh "curl -u ${env.SONAR_AUTH_TOKEN}: -X POST \"${env.SONAR_HOST_URL}/api/qualitygates/select?gateId=${numGateId}&projectKey=${config.groupid}:${config.artifactid}:${env.BRANCH_NAME}\""
	} catch (error) {
		new com.scor.utils.catchFailureBuild().call(config, "set sonar quality gate")
	}   
    def ceTask
    timeout(time: 15, unit: 'MINUTES') {
    	waitUntil {
			// note : SONAR_CE_TASK_URL has been declared within the function mavenCodeAnalyseSonarAnalysis
    		sh "curl -u ${SONAR_AUTH_TOKEN} ${SONAR_CE_TASK_URL} -o ceTask.json"
    		ceTask = readJSON file:'ceTask.json'
    		return "SUCCESS".equals(ceTask["task"]["status"])
    	}
    }
    def qualityGateUrl = env.SONAR_HOST_URL + "/api/qualitygates/project_status?analysisId=" + ceTask["task"]["analysisId"]
    sh "curl -u ${SONAR_AUTH_TOKEN} ${qualityGateUrl} -o qualityGate.json"
    def qualitygate = readJSON file:'qualityGate.json'
    if ("ERROR".equals(qualitygate["projectStatus"]["status"])) {
		new com.scor.utils.catchFailureBuild().call(config, "set sonar quality gate")
    }
    }
}
}