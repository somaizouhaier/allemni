def call() {
global_var_map = [
    project_name : "DEVOPS",
    sonar_gateid : "low-restriction-not-blocking",
    maven_sonar_profile : "coverage",
    maven_rootpom_directory : "",
    maven_frontpom_directory : "",
    mavenPomNameAnchor : "finalName",
    node_name : "dcvprdadm04",
    build_environment : "none"
]

node ("${global_var_map.node_name}") {
    List javaEnv = new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    withEnv(javaEnv) {
    new com.scor.utils.scmCheckout().call()
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    new com.scor.maven.updateConfiguration().call(global_var_map)
    new com.scor.utils.buildDisplayName().call(global_var_map)
    new com.scor.maven.releaseversionControl().call(global_var_map)
    new com.scor.maven.scanWar().call(global_var_map)
    new com.scor.maven.codeAnalyser().call(global_var_map)
    new com.scor.sweagle.getFrontConfiguration().call(global_var_map)
    new com.scor.infrastructure.ansible.frontend.nginx().call(global_var_map)
    }
}
}