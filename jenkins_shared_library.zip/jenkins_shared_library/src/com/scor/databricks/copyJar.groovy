package com.scor.databricks

def call(Map config, String finalName, String groupId, String artifactId, String module) {
        try {       
        sh "databricks fs cp --overwrite /scor/delivery/Nexus_download/${config.project_name}/${finalName}/${config.environment}/jar/${finalName}.jar dbfs:/FileStore/jars/${finalName}.jar --profile ${config.project_name}-${config.environment}"
        } catch (error) {
                throw (error)
        }
}