package com.scor.infrastructure.ansible.azure.DXC

def call (Map config) {
stage ("Ansible Create Azure Windows VM SQL: ${config.project_name} ${config.environment}") {
    try {
        dir ("${config.ansible_playbook_dir}/azure/ansible-playbooks-azure") {
        autoshutdown = sh (
        script: "cat ${config.sweagle_stored_dir}/infrastructure/ansible/azure/vm/vars/${config.project_name}/${config.environment}/azurevm_windows_sql_vars.yml |grep tag_dxc_autoshutdown | cut -d ':' -f 2",
        returnStdout: true ).trim()
        status = sh (
        script: "ansible-playbook playbook_azure_create_dxc_server_windows_sql.yml -e app_name=${config.project_name} -e env=${config.environment} --private-key ${config.ansible_playbook_dir}/azure/ssh_key/rootlnxazure_private_key -i ${config.sweagle_stored_dir}/infrastructure/ansible/azure/vm/vars/${config.project_name}/${config.environment}/win_sql_hosts",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Windows VM SQL: ${config.project_name} ${config.environment}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Windows VM SQL: ${config.project_name} ${config.environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible Create Azure Windows VM SQL: ${config.project_name} ${config.environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
    }
}
