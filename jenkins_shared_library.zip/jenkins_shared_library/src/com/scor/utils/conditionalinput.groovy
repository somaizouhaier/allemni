package com.scor.utils

def call(Map config, String message) {

def userInput = "none"
    def didTimeout = false
    stage ('Conditional Input') {
        try {
            timeout(time: 30, unit: 'SECONDS') { // change to a convenient timeout for you
                userInput = input(
                id: 'Proceed1', message: "${message}", parameters: [
                [$class: 'BooleanParameterDefinition', defaultValue: true, description: '', name: "${message}"]
                ])
            }
        } catch(err) { // timeout reached or input false
            def user = err.getCauses()[0].getUser()
            if('SYSTEM' == user.toString()) { // SYSTEM means timeout.
                didTimeout = true
            } else if (userInput != true) {
                userInput = false
            } else if (userInput == true) {
                userInput = true
            }
        }
    }
return userInput
}