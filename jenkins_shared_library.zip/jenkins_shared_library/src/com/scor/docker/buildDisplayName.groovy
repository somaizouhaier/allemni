package com.scor.docker

def call (Map config) {
	currentBuild.displayName = "${config.project_name}-${config.environment}-${env.BRANCH_NAME}-${config.version}"
}