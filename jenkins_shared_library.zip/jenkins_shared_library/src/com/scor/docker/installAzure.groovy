package com.scor.docker

def call (Map config) {
    Map params = [
            stepName : "Ansible Install Docker DXC: ${config.project_name} ${config.environment}",
            ansiblePlaybookDir : "${config.ansible_playbook_dir}/container/ansible-playbooks-docker",
            script : "ansible-playbook playbook_docker.yml -e app_name=${config.project_name} -e env=${config.environment} --private-key ${config.ssh_keyPath}/azure_private_key -i ${config.sweagle_stored_dir}/infrastructure/ansible/container/docker/host/${config.project_name}/${config.environment}/docker_host.yml -e group_hosts=docker"
    ]

    new com.scor.utils.ansiblePlaybookRun().call(config, params)
}
