package com.scor.maven

def call (Map global_var_map) {
	Map fullmapmodule = [:]
	Map warmapmodule = [:]
    new com.scor.maven.scanWarGetmodules().call(fullmapmodule, "${global_var_map.pompath}")
    new com.scor.maven.scanWarFiltermodules().call(fullmapmodule, warmapmodule)
	global_var_map << [fullmapmodule : fullmapmodule]
	global_var_map << [warmapmodule : warmapmodule]
}
