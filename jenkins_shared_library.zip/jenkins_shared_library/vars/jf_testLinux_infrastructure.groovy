def call() {
global_var_map = [
    project_name : "TESTLINUX",
    ansible_playbook_dir : "/scor/CI-Factory/ansible/playbooks",
    node_name : "dcvprdadm04",
    build_environment : "TST"
]

node ("${global_var_map.node_name}") {
    new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    new com.scor.utils.scmCheckout().call()
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    print "${global_var_map.project_name},${global_var_map.environment}"
    new com.scor.sweagle.getProjectInfrastructureConfiguration().call(global_var_map)
    groovyfunctions = [
        call_infrastructureAnsibleAzureLinuxVm : "${global_var_map.project_name},${global_var_map.environment}",
    ]
    new com.scor.utils.groovyParallelLauncher().call(groovyfunctions)
    new com.scor.sweagle.uploadHosts().call(global_var_map)
    new com.scor.utils.influxdb().record(global_var_map)
    new com.scor.utils.mail().send(global_var_map)
}
}
