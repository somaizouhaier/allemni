package com.scor.docker

def call(Map config, Map projectElementMap) {
  stage ('Docker push'){
    project = config.project_name.toLowerCase()
    version = config.version.trim()
    if ("${config.branchName.contains("master")}" == "true") {
      projectElementMap.each {
        sh "docker push ${config.artifactoryHost}/${project}/${it.key}:master-${version}"
        sh "docker push ${config.artifactoryHost}/${project}/${it.key}:latest"
      }
    } else {
      projectElementMap.each {
        sh "docker push ${config.artifactoryHost}/${project}/${it.key}:develop-${version}"
        sh "docker push ${config.artifactoryHost}/${project}/${it.key}:develop-latest"
      }
    }
  }
}
