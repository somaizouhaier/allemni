package com.scor.utils

def call (global_var_map) {
    global_var_map << [ansible_playbook_dir : "/scor/CI-Factory/ansible/playbooks"]
    global_var_map << [sweagle_stored_dir : "/scor/delivery/sweagle"]
    global_var_map << [sweagle_shell_dir : "/scor/CI-Factory/shell/sweagle"]
    global_var_map << [nexus_shell_dir : "/scor/CI-Factory/shell/nexus"]
    global_var_map << [databricks_shell_dir : "/scor/CI-Factory/shell/databricks"]
    global_var_map << [workspace : pwd()]
	global_var_map << [nexus_host : "10.20.1.73"]
	global_var_map << [nexus_port : "8082"]
	global_var_map << [sweagleUrl : "http://dcvprdsweagle.eu.scor.local"]
	global_var_map << [sweagleToken : "9fdbb548-647a-45d4-b20e-3a5a419f1917"]
    global_var_map << [dockerUser : "u006252"]
    global_var_map << [dockerPassword : "AP3yDD5CQy5G36X6VU31ict4yt1"]
    global_var_map << [artifactoryHost : "docker.artifactory.eu.scor.local"]
    global_var_map << [ssh_keyPath: "/scor/CI-Factory/ansible/ssh_key/sshkey_list" ]
    global_var_map << [ansible_config_dir : "/scor/CI-Factory/ansible/configuration" ]
    global_var_map << [branchName : "${env.BRANCH_NAME}"]
    global_var_map << [buildNumber : "${env.BUILD_NUMBER}"]
}
