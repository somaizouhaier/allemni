package com.scor.infrastructure.ansible

def call (Map config) {
stage ("Ansible Configure Monitoring Solution: ${config.project_name} ${config.environment}") {

    def exists = fileExists "/scor/delivery/sweagle/infrastructure/ansible/azure/vm/vars/${config.project_name}/${config.environment}/monitoring_vars.yml"
    if (exists) {
    try {
        dir ("${config.ansible_playbook_dir}/monitoring/ansible-playbooks-monitoring") {
        status = sh (
        script: "ansible-playbook playbook_monitoring.yml -e app_name=${config.project_name} -e env=${config.environment} -i /scor/delivery/sweagle/global_variables/hosts/Azur/${config.project_name}/${config.environment}/dip01.yml",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible Configure Monitoring Solution: ${config.project_name} ${config.environment}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible Configure Monitoring Solution: ${config.project_name} ${config.environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible Configure Monitoring Solution: ${config.project_name} ${config.environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
    }
    else {
      println "No Monitoring configured - ${config.project_name} ${config.environment}"
    }
}
}
