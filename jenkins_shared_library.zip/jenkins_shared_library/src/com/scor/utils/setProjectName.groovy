package com.scor.utils

def call (global_var_map) {
    def projectName = sh(returnStdout: true, script: "echo \\${JOB_NAME} | rev | cut -d '/' -f 1 | rev").trim()
    println "${projectName}"
    global_var_map << [project_name : "${projectName}"]
}