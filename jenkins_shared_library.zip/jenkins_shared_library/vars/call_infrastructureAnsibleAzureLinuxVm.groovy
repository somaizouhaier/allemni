def call (String project_name, String environment)  {
    new com.scor.infrastructure.ansible.azure.linuxVm().call("${project_name}","${environment}")
}