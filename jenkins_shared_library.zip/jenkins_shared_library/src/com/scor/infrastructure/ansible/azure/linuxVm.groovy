package com.scor.infrastructure.ansible.azure

def call (String project_name, String environment) {
stage ("Ansible Create Azure Linux VM: ${project_name} ${environment}") {
    try {
        def ansible_playbook_dir = "/scor/CI-Factory/ansible/playbooks"
        def config = [:]
        dir ("${ansible_playbook_dir}/azure/ansible-playbooks-azure") {
        status = sh (
        script: "ansible-playbook playbook_azure_create_server_linux.yml -e app_name=${project_name} -e env=${environment} --private-key ${ansible_playbook_dir}/azure/ssh_key/rootlnxazure_private_key -i ${config.ansible_config_dir}/azure/vm/${config.project_name}/${config.environment}/linux_hosts",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Linux VM: ${project_name} ${environment}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Linux VM: ${project_name} ${environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible Create Azure Linux VM: ${project_name} ${environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
}
}
