def call() {
global_var_map = [
    project_name : "CTT",
    sonar_gateid : "low-restriction-not-blocking",
    maven_sonar_profile : "coverage",
    maven_rootpom_directory : "",
    mavenPomNameAnchor : "artifactId",
    node_name : "dcvprdadm04",
    build_environment : "DEV"
]
node ("${global_var_map.node_name}") {
    List javaEnv = new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    withEnv(javaEnv) {
    new com.scor.utils.scmCheckout().call()
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    new com.scor.maven.updateConfiguration().call(global_var_map)
    new com.scor.utils.buildDisplayName().call(global_var_map)
    new com.scor.maven.releaseversionControl().call(global_var_map)
    new com.scor.maven.scanWar().call(global_var_map)
    new com.scor.maven.codeAnalyser().call(global_var_map)
    new com.scor.maven.parallelLauncher().call(global_var_map, "call_sweagleGetConfiguration", "Sweagle Get Configuration" )
    new com.scor.maven.parallelLauncher().call(global_var_map, "call_infrastructureAnsibleBackendTomcat", "Infrastructure Ansible Backend Tomcat" )
    new com.scor.utils.influxdb().record(global_var_map)
    new com.scor.utils.mail().send(global_var_map)
    }
}
}