package com.scor.infrastructure.ansible.backend

def call (Map config) {
stage ("Ansible Backend Nodejs ${config.application}") {
    try {
        dir ("${config.ansible_playbook_dir}/backend/nodejs") {
        status = sh (
        script: "ansible-playbook -i ${config.sweagle_stored_dir}/infrastructure/ansible/backend/nodejs/host/${config.project_name}/${config.environment}/${config.application}/nodejs_host.yml playbook_nodejs.yml",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "infrastructure ansible backend nodejs ${config.application}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "infrastructure ansible backend nodejs ${config.application}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "infrastructure ansible backend nodejs ${config.application}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
}
}