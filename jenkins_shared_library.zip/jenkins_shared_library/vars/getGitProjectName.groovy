def call () {
    return scm.getUserRemoteConfigs()[0].getUrl().split("\\.")[0].split("/")[-1]
}