package com.scor.utils

def call(Map groovyfunctions) {
  node ('dcvprdadm04'){

  // you can launch in parallel as many function as you want but keep in mind that
  // each function take at least one thread on the node (15 thread today on dcvprdadm04)

  // sample of entry map :

  //groovyfunctions = [
  //groovyfunction1 : "${arg1},${arg2}",            //(!!any space between "," in arguments list will be taken into account!!)
  //groovyfunction2 : "${arg1},${arg2},${arg3}",    // (take any args number)
  //groovyfunction3 : "${arg1}
  //]

  //sample of call : new com.scor.utils.groovyParallelLauncher().call(groovyfunctions)

  def stagesForParallel = groovyfunctions.collectEntries { stageName, arguments ->
  //parallel stuff here
  ["${stageName}" : transformIntoStage(stageName, arguments)]
  }

  stage ('Parallel Groovy Launcher') {
  parallel stagesForParallel
  }

  } //end node
} //end call

def transformIntoStage(stageName, arguments) {
    return {
        node ('dcvprdadm04') {
            stage (stageName) {
                //change arguments from list to string to use them as groovy function parameters
                parameterList = arguments.split(',').collect{it as String}
                try {
                    "${stageName}"(parameterList)
                    } catch (error) {
                    throw (error) 
                }
            }
        }
    }
}
