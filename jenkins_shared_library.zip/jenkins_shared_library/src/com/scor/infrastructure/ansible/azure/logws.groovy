package com.scor.infrastructure.ansible.azure

def call (Map config) {
stage ("Ansible Create Azure Log Analytics workspace: ${config.project_name} ${config.environment}") {
    def exists = fileExists "/scor/delivery/sweagle/infrastructure/ansible/azure/vm/vars/${config.project_name}/${config.environment}/azure_logsws_vars.yml"
    if (exists) {
    try {
        dir ("${config.ansible_playbook_dir}/azure/ansible-playbooks-azure") {
        status = sh (
        script: "ansible-playbook playbook_azure_create_logws.yml -e app_name=${config.project_name} -e env=${config.environment}",
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Log Analytics workspace: ${config.project_name} ${config.environment}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible Create Azure Log Analytics workspace: ${config.project_name} ${config.environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible Create Azure Log Analytics workspace: ${config.project_name} ${config.environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
    }
    else {
      println "No Log Analytics workspace configured - ${config.project_name} ${config.environment}"
    }
}
}
