package com.scor.sweagle

def call (Map config, String componentName) {

stage ("Ansible Sweagle Create Includes ${config.project} ${config.application} ${config.new_environment} ${componentName}") {
    try {
        dir ("${config.ansible_playbook_dir}/sweagle/ansible-playbooks-sweagle") {
        status = sh (
        script: "ansible-playbook playbook_sweagle_pull_include.yml -e project_name=${config.project} -e env=${config.new_environment} -e application=${config.application} -e sweagle_url=${config.sweagleUrl} -e token=${config.sweagleToken} -e host_provider=${config.hostProvider} -e ${componentName}=true", 
        returnStatus: true
        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
        }
        else {
                currentBuild.result = "FAILURE"
        throw (error)
        }
     } finally {
        }
}

}