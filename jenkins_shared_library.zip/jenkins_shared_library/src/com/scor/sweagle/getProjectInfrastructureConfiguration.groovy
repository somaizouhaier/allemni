package com.scor.sweagle

def call (Map config) {
    stage ("Sweagle Get ${config.project_name} Configuration") {
    try {
        sh "${config.sweagle_shell_dir}/retrieve_all_configuration/scorGetConfigByAppEnvrt.sh ${config.project_name} ${config.environment} infrastructure ${config.sweagle_stored_dir}"
     } catch (error) {
        new com.scor.utils.catchFailureBuild().call(config, "sweagle get project configuration")
            }
    }
}