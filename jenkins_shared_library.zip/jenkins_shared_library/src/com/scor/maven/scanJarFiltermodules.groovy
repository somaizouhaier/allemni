package com.scor.maven

def call (Map fullmapmodule, Map jarmapmodule) {
    fullmapmodule.each { module, pompath ->
        modulePomfile = readMavenPom file: "${pompath}"
        if ("${modulePomfile.packaging}" == "jar") {
            if ("${modulePomfile.properties.tobedeployed}" != "false") {
                jarmapmodule.put("${module}", "${pompath}")
            }
        }
    }
}
return jarmapmodule