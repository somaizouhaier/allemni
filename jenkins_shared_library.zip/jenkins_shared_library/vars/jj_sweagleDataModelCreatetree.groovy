def call(Map config) {

new com.scor.utils.setGlobalConfiguration().call(config)
if ("${Action_Type}" == "create_tree_from_scratch") {

    for (String app : "${applicationList}".split(",")) {
        config << [ application : "${app}" ]
        for (String comp : "${componentList}".split(",")) {
            new com.scor.sweagle.createTree().call(config, "${comp}")
        }
        new com.scor.sweagle.createMetadataset().call(config)
        for (String comp : "${componentList}".split(",")) {   
            new com.scor.sweagle.createIncludes().call(config, "${comp}")
        }
    }
}

if ("${Action_Type}" == "create_tree_from_existing_env") {
currentBuild.displayName = "${Action_Type}-${project}-${environment}-${new_environment}-${applicationList}-${componentList}"
config << [ new_environment : "${new_environment}" ]
    for (String app : "${applicationList}".split(",")) {
      config << [ application : "${app}" ]
        for (String comp : "${componentList}".split(",")) {
            new com.scor.sweagle.copyTree().call(config, "${comp}")
            new com.scor.sweagle.createTreeNewEnvironment().call(config, "${comp}")
        }
        new com.scor.sweagle.createMetadatasetNewEnvironment().call(config)
        for (String comp : "${componentList}".split(",")) {   
            new com.scor.sweagle.createIncludesNewEnvironment().call(config, "${comp}")
        }
    }
}
}

