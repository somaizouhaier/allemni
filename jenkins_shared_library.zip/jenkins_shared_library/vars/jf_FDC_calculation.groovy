def call() {
global_var_map = [
    project_name : "FDC",
    sonar_gateid : "low-restriction-not-blocking",
    maven_sonar_profile : "coverage",
    maven_rootpom_directory : "",
    maven_frontpom_directory : "",
    mavenPomNameAnchor : "artifactId",
    node_name : "dcvprdadm04",
    build_environment : "DEV"
]

node ("${global_var_map.node_name}") {
    def server
    List javaEnv = new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    withEnv(javaEnv) {
    new com.scor.utils.scmCheckout().call()
    new com.scor.utils.setenvironment().call(global_var_map)
    new com.scor.utils.setGlobalConfiguration().call(global_var_map)
    new com.scor.maven.updateConfiguration().call(global_var_map)
    new com.scor.utils.buildDisplayName().call(global_var_map)
    new com.scor.maven.releaseversionControl().call(global_var_map)
    new com.scor.maven.scanWar().call(global_var_map)
    new com.scor.maven.codeAnalyser().call(global_var_map)
    new com.scor.sweagle.getFrontConfiguration().call(global_var_map)
    new com.scor.infrastructure.ansible.frontend.nginx().call(global_var_map)
    stage ("Nodejs PM2 process launcher") {
    try {
    if ("${global_var_map.maven_frontpom_directory}" == "") {
        frontpom = readMavenPom file: "pom.xml"
    } else {
    frontpom = readMavenPom file: "${global_var_map.maven_frontpom_directory}/pom.xml"
    }
    if ("${global_var_map.environment}" == "DEV") {
        server = "dcvdevsmil"
    } else if ("${global_var_map.environment}" == "UAT") {
        server = "dcvuatsmil"
    } else if ("${global_var_map.environment}" == "PRD") {
        server = "dcvprdsmil"
    }
        sh "ssh -i /scor/CI-Factory/ansible/ssh_key/sshkey_list/tomcat_private_key tomcat@${server} \"export PATH=$PATH:/scor/nginx/${global_var_map.environment}_${frontpom.build.finalName}/node && cd /scor/nginx/${global_var_map.environment}_${frontpom.build.finalName} && sudo --preserve-env=PATH node/node node_modules/pm2/bin/pm2 delete all && sudo --preserve-env=PATH node/node node_modules/pm2/bin/pm2 start deploy.json\""
     } catch (error) {
        sh "ssh -i /scor/CI-Factory/ansible/ssh_key/sshkey_list/tomcat_private_key tomcat@${server} \"export PATH=$PATH:/scor/nginx/${global_var_map.environment}_${frontpom.build.finalName}/node && cd /scor/nginx/${global_var_map.environment}_${frontpom.build.finalName} && sudo --preserve-env=PATH node/node node_modules/pm2/bin/pm2 start deploy.json\""
            }
    }
    new com.scor.utils.influxdb().record(global_var_map)
    new com.scor.utils.mail().send(global_var_map)
    }
}
}