package com.scor.sweagle

def call (Map config) {
    Map params = [
            stepName : "Ansible Sweagle Copy Metadataset ${config.project}_${config.environment}_${config.application}",
            ansiblePlaybookDir : "${config.ansible_playbook_dir}/sweagle/ansible-playbooks-sweagle",
            script : "ansible-playbook playbook_sweagle_copy_metadata_set.yml -e project_name=${config.project} -e env=${config.environment} -e app_name=${config.application} -e sweagle_url=${config.sweagleUrl} -e token=${config.sweagleToken} -e appfile=true -e new_env=${config.environment}"
    ]

    new com.scor.utils.ansiblePlaybookRun().call(config, params)

}