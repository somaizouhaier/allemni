

def call () {
    return scm.getUserRemoteConfigs()[0].getUrl().split("/")[-1]
}