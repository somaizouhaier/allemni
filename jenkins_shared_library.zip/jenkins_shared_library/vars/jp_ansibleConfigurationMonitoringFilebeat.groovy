def call() {
node('dcvprdadm03') {
def config = [:]
config << [collection : "CI-Factory"]
config << [UserProjectName : "ansible-configuration-monitoring"]
config << [UserGitRepoName : "filebeat"]
config << [UserBranch : "${env.BRANCH}"]
new com.scor.git.gitPullTFSOnSlaves().call(config)
}
}