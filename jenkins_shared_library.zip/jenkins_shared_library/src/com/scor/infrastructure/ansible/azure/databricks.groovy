package com.scor.infrastructure.ansible.azure

def call (Map config) {

    Map params = [
            stepName : "Ansible Create Azure Databricks: ${config.project_name} ${config.environment}",
            ansiblePlaybookDir : "${config.ansible_playbook_dir}/azure/ansible-playbooks-azure",
            script : "ansible-playbook playbook_azure_create_databricks.yml -e app_name=${config.project_name} -e env=${config.environment}"
    ]

    new com.scor.utils.ansiblePlaybookRun().call(config, params)
}
