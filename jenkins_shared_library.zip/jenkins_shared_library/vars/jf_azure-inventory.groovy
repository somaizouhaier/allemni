def call() {
global_var_map = [
    node_name : "dcvprdoperatio"
]

node ("${global_var_map.node_name}") {
    List javaEnv = new com.scor.utils.addGlobalToolAndPath().call("jdk1.8.0_60", 'Maven 3.3.9')
    withEnv(javaEnv) {
    new com.scor.utils.scmCheckout().call()
    stage ("launch Azure Inventory Script") {
        bat "powershell.exe -NonInteractive -ExecutionPolicy Bypass .\\test.ps1" 
        }
    }
}
}