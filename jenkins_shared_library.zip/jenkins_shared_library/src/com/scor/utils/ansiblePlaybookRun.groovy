package com.scor.utils

def call (Map config, Map params) {
	stage (params.stepName) {
		try {
			dir (params.ansiblePlaybookDir) {
				status = sh (
						script: params.script,
						returnStatus: true
				)
			}
			if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
				unstable(message : "this stage is unstable")
				currentBuild.result = "UNSTABLE"
				config << [status : "${currentBuild.result}", step : params.stepName]
			}
			else if ("${status}" == "0") {
				currentBuild.result='SUCCESS'
				config << [status : "${currentBuild.result}", step : params.stepName]
			}
			else {
				currentBuild.result = "FAILURE"
				config << [status : "${currentBuild.result}", step : params.stepName]
				new com.scor.utils.mail().send(config)
				throw (error)
			}
		}
		finally {
		}
	}
}
