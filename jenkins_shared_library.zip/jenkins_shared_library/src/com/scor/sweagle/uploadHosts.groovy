package com.scor.sweagle

def call (Map config) {
stage ("Push hosts file to sweagle: ${config.project_name} ${config.environment}") {
    def exists_linux         = fileExists "/scor/delivery/sweagle/infrastructure/ansible/azure/vm/vars/${config.project_name}/${config.environment}/linux_hosts"
    def exists_windows       = fileExists "/scor/delivery/sweagle/infrastructure/ansible/azure/vm/vars/${config.project_name}/${config.environment}/win_hosts"
    def ansible_playbook_dir = "/scor/CI-Factory/ansible/playbooks"
    if (exists_linux) {
    try {
        dir ("${ansible_playbook_dir}/sweagle/ansible-playbooks-sweagle") {
        status = sh (
	script: "ansible-playbook playbook_sweagle_upload_files.yml -e sweagle_url=${config.sweagleUrl} -e token=${config.sweagleToken} -e '{\"files\":[{\"name\": \"linux_hosts\", \"sweagle_path\": \"infrastructure,ansible,azure,vm,vars,${config.project_name},${config.environment}\", \"file_path\": \"/scor/delivery/sweagle/infrastructure/ansible/azure/vm/vars/${config.project_name}/${config.environment}\", \"format\": \"INI\"}]}'",
        returnStatus: true

        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible upload linux hosts to sweagle: ${config.project_name} ${config.environment}"]
        }
        else if ("${status}" == "0") { 
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible upload linux hosts to sweagle: ${config.project_name} ${config.environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible upload linux hosts to sweagle: ${config.project_name} ${config.environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
    }
    else {
      println "No Linux hosts configured - ${config.project_name} ${config.environment}"
    }
    if (exists_windows) {
    try {
        dir ("${ansible_playbook_dir}/sweagle/ansible-playbooks-sweagle") {
        status = sh (
        script: "ansible-playbook playbook_sweagle_upload_files.yml -e sweagle_url=${config.sweagleUrl} -e token=${config.sweagleToken} -e '{\"files\":[{\"name\": \"win_hosts\", \"sweagle_path\": \"infrastructure,ansible,azure,vm,vars,${config.project_name},${config.environment}\", \"file_path\": \"/scor/delivery/sweagle/infrastructure/ansible/azure/vm/vars/${config.project_name}/${config.environment}\", \"format\": \"INI\"}]}'",
        returnStatus: true

        )
        }
        if (("${status}" == "1") || ("${status}" == "2") || ("${status}" == "3")) {
            unstable(message : "this stage is unstable")
            currentBuild.result = "UNSTABLE"
            config << [status : "${currentBuild.result}", step : "Ansible upload windows hosts to sweagle: ${project_name} ${environment}"]
        }
        else if ("${status}" == "0") {
            currentBuild.result='SUCCESS'
            config << [status : "${currentBuild.result}", step : "Ansible upload windows hosts to sweagle: ${project_name} ${environment}"]
        }
        else {
                currentBuild.result = "FAILURE"
                config << [status : "${currentBuild.result}", step : "Ansible upload windows hosts to sweagle: ${project_name} ${environment}"]
                new com.scor.utils.mail().send(config)
        throw (error)
        }
     } finally {
        }
    }
    else {
      println "No Windows hosts configured - ${config.project_name} ${config.environment}"
    }
}
}
