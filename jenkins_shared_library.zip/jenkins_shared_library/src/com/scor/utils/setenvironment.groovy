package com.scor.utils

def call (global_var_map) {
    def cur_environment = sh(returnStdout: true, script: "echo \\${JOB_NAME} | rev | cut -d '/' -f 2 | rev").trim()
    global_var_map << [environment : "${cur_environment}"]
}