package com.scor.maven

def call (Map config) {
	stage ('Maven Unitary Tests') {
	try {

	sh "mvn -f ${config.pompath}/pom.xml clean test -P${config.maven_sonar_profile}"
	} catch (error) {
		new com.scor.utils.catchFailureBuild().call("maven unitary tests")
		}
    }
}