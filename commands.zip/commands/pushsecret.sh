#!/bin/bash
sweagle_stored_dir=$1
project_name=$2
environment=$3
application=$4
databricksScope=$5

for k in $(cat $sweagle_stored_dir/application/configuration/$project_name/$environment/$application/databricks.json | jq -r 'keys | . []'); do databricks secrets put --scope $databricksScope --key $k --string-value $(cat $sweagle_stored_dir/application/configuration/$project_name/$environment/$application/databricks.json | jq -r ".$k") --profile $project_name-$environment; done