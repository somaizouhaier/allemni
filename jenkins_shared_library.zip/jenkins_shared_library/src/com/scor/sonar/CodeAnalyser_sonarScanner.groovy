package com.scor.sonar

def call(Map config) {
    def flagNoPom = 0
    if ("${config.build_environment.contains("${config.environment}")}" == "true") {
        if ("${config.version.endsWith("SNAPSHOT")}" == "false") {
            def codereturn_nexusCheckbinaryMaven = new com.scor.utils.nexusCheckbinaryMaven().call(config)
            if ("${codereturn_nexusCheckbinaryMaven}" == "1") {
                flagNoPom = flagNoPom + 1;
            }
        }
        if ("${config.version.endsWith("SNAPSHOT")}" == "true") {

            if (new com.scor.utils.conditionalinput().call(config, "Perform Sonar analysis ?") == true) {
                new com.scor.maven.codeAnalyserUnitTest().call(config)
                //new com.scor.maven.codeAnalyser().callIntegrationTest(config)
                //new com.scor.maven.codeAnalyser().callSonarAnalysis(config)
                new com.scor.sonar.sonarScanner().call(config)
                new com.scor.sonar.sonarQualitygate().call(config)
            }
        } else if ( flagNoPom > 0 ) {
                new com.scor.maven.codeAnalyserUnitTest().call(config)
                //new com.scor.maven.codeAnalyser().callIntegrationTest(config)
                //new com.scor.maven.codeAnalyser().callSonarAnalysis(config)
                new com.scor.sonar.sonarScanner().call(config)
                new com.scor.sonar.sonarQualitygate().call(config)
        }
    } else {
        if ("${config.version.endsWith("SNAPSHOT")}" == "false") {
            def codereturn_nexusCheckbinaryMaven = new com.scor.utils.nexusCheckbinaryMaven().call(config)
            if ("${codereturn_nexusCheckbinaryMaven}" == "1") {
                error "The version ${config.version} is not present on the repository manager, please launch first a build on the following build environment list : ${config.build_environment}"
            }
        }
    }
    if ("${config.build_environment.contains("${config.environment}")}" == "true") {
        if ("${config.version.endsWith("SNAPSHOT")}" == "false") {
                if ( flagNoPom > 0 ) {
                    new com.scor.maven.buildNexus().call(config)
                } else {
                println "The version ${config.version} is already built, skipping the build stage"
                }
                // ...       
        } else {
            new com.scor.maven.buildNexus().call(config)
        }
    }
}